"""Bounded current LinkedIn company-size evidence from Exa Contents."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import unicodedata
from types import SimpleNamespace
from typing import Any, Literal, Mapping, Optional, TypedDict, Union
from urllib.parse import urlsplit

import aiohttp

from gateway.qualification.models import (
    candidate_linkedin_prompt_slug, canonical_candidate_prompt_url,
)
from lab_arena.scoring_provider_compat import (
    CompatibilityResponseError,
    _firecrawl_response,
)
from qualification.competition_models import public_http_url
from leadpoet_verifier.identity.normalization import (
    NormalizationError,
    normalize_host,
)
from qualification.employee_buckets import LINKEDIN_EMPLOYEE_BUCKETS
from qualification.company_quality import canonical_us_state
from qualification.scoring.pre_checks import _resolve_country
from qualification.scoring.company_fit_decision import (
    _company_name, observed_linkedin_ampersand_slug, verified_homepage_brand_name,
)


logger = logging.getLogger(__name__)

PROFILE_MAX_CHARACTERS = 4_000
PROFILE_TIMEOUT_SECONDS = 30.0
# Exa defaults live crawls to 10 seconds.  Keep this below the outer request
# timeout while giving the exact fresh-profile fetch more time to complete.
PROFILE_LIVECRAWL_TIMEOUT_MILLISECONDS = 20_000
STRUCTURED_PROFILE_TIMEOUT_SECONDS = 30.0
STRUCTURED_PROFILE_PROVIDER = "harvestapi_get_company"
STRUCTURED_PROFILE_SOURCE_FIELD = "employeeCountRange"
STRUCTURED_PROFILE_COMPANY_TYPE_SOURCE_FIELD = "companyType"
STRUCTURED_PROFILE_IDENTITY_SOURCE_FIELD = "name"
STRUCTURED_PROFILE_DESCRIPTION_SOURCE_FIELD = "description"
STRUCTURED_PROFILE_HEADQUARTERS_SOURCE_FIELD = "locations.headquarter"
STRUCTURED_PROFILE_PUBLIC_COMPANY_TYPE = "Public Company"
STRUCTURED_PROFILE_PRIVATE_COMPANY_TYPE = "Privately Held"
CURRENT_LINKEDIN_SIZE_INSUFFICIENT_EVIDENCE: Literal[
    "insufficient_evidence"
] = "insufficient_evidence"

_ABOUT_SECTION_HEADING = re.compile(
    r"(?:#{1,6}\s*)?(?:About(?: us)?|Over ons|Sobre nós)",
    re.IGNORECASE,
)
_ABOUT_SECTION_END_HEADING = re.compile(
    r"(?:#{1,6}\s*)?(?:Employees(?: at\b.*)?|Medewerkers van(?:\b.*)?|"
    r"Funcionários da(?:\b.*)?|Updates)",
    re.IGNORECASE,
)
_COMPANY_SIZE_FIELD = re.compile(
    r"(?:\*\*)?(?:Company size|Bedrijfsgrootte|Tamanho da empresa)"
    r"(?:\*\*)?\s*:?(?:\s+(?P<value>.+))?",
    re.IGNORECASE,
)
_EMPLOYEE_SUFFIX = re.compile(
    r"\s+(?:employees?|medewerkers|funcionários)\s*$",
    re.IGNORECASE,
)

# These are exact LinkedIn authentication-page titles, paired with credential
# fields. A public company page can contain sign-in links, so links or isolated
# authentication words are not enough to classify the fetch as blocked.
_ACCESS_WALL_TITLES = {
    "aanmelden | linkedin",
    "anmelden | linkedin",
    "cadastre-se | linkedin",
    "daftar | linkedin",
    "entrar | linkedin",
    "inloggen | linkedin",
    "inschrijven | linkedin",
    "iscriviti | linkedin",
    "join linkedin",
    "linkedin login, sign in",
    "registrarse | linkedin",
    "zarejestruj się | linkedin",
    "s’inscrire | linkedin",
    "sign in | linkedin",
    "sign up | linkedin",
    "đăng ký | linkedin",
    "εγγραφή | linkedin",
    "الاشتراك | linkedin",
    "ลงทะเบียน | linkedin",
}
_ACCESS_WALL_CREDENTIAL_FIELDS = (
    ("adres e-mail lub numer telefonu", "hasło"),
    ("e-mail-adresse/telefon", "passwort"),
    ("e-mail of telefoonnummer", "wachtwoord"),
    ("e-mel atau nombor telefon", "kata laluan"),
    ("email atau telepon", "kata sandi"),
    ("email or phone", "password"),
    ("email o telefono", "password"),
    ("email ή τηλέφωνο", "κωδικός πρόσβασης"),
    ("email", "contraseña"),
    ("email", "mật khẩu"),
    ("e-mail", "senha"),
    ("e-mail", "mot de passe"),
    ("e-mail", "wachtwoord"),
    ("البريد الإلكتروني أو رقم الهاتف", "كلمة المرور"),
    ("อีเมลหรือโทรศัพท์", "รหัสผ่าน"),
)
_BLOCKED_PAGE_TITLES = {
    "access denied",
    "access denied | linkedin",
    "robot check",
    "robot check | linkedin",
    "security check | linkedin",
    "security verification | linkedin",
}
_BLOCKED_PAGE_MARKERS = (
    "access to this page has been denied",
    "additional verification required",
    "checking your browser",
    "request blocked",
    "security check",
    "verify you are human",
    "verifying you are human",
    "you don't have permission to access",
)


class CurrentLinkedInCompanySizeEvidence(TypedDict):
    employee_count: str
    quote: str
    url: str


class CurrentLinkedInCompanySizeInsufficientEvidence(TypedDict):
    outcome: Literal["insufficient_evidence"]
    url: str


CurrentLinkedInCompanySizeResult = Union[
    CurrentLinkedInCompanySizeEvidence,
    CurrentLinkedInCompanySizeInsufficientEvidence,
]


class StructuredLinkedInCompanySizeEvidence(TypedDict):
    employee_count: str
    provider: str
    source_field: str
    url: str
    website: str


class StructuredLinkedInPublicCompanyEvidence(TypedDict):
    company_type: str
    provider: str
    source_field: str
    url: str
    website: str


class StructuredLinkedInCompanyIdentityEvidence(TypedDict):
    name: str
    provider: str
    source_field: str
    url: str
    website: str


class StructuredLinkedInCompanyDescriptionEvidence(TypedDict):
    name: str
    text: str
    provider: str
    source_field: str
    url: str
    website: str


VERIFIER_FAILURE_REASON_KEY = "failure_reason"
SOURCE_BLOCKED_FAILURE_REASON = "source_blocked"
MALFORMED_RESPONSE_FAILURE_REASON = "malformed_response"
PROVIDER_ERROR_FAILURE_REASON = "provider_error"
UNEXPECTED_VERIFIER_ERROR_FAILURE_REASON = "unexpected_verifier_error"


def _set_failure_reason(diagnostic: Optional[dict[str, str]], reason: str) -> None:
    """Set one fixed diagnostic code without retaining provider data."""

    if diagnostic is not None:
        diagnostic[VERIFIER_FAILURE_REASON_KEY] = reason


def linkedin_company_page_slug(value: Any) -> str:
    """Return one strict LinkedIn company slug from an HTTP(S) profile URL."""

    try:
        slug = candidate_linkedin_prompt_slug(
            value,
            "employee_size_evidence_url",
        )
        parsed = urlsplit(str(value))
    except (TypeError, ValueError):
        # An independently observed company locator may contain an ampersand.
        # Keep the miner prompt grammar unchanged; validate the full URL before
        # admitting this one separately bounded, single-decoded component.
        try:
            canonical_candidate_prompt_url(value, "employee_size_evidence_url")
            parsed = urlsplit(value)
            host = str(parsed.hostname or "").casefold()
            parts = [part for part in parsed.path.split("/") if part]
            if (
                not (host == "linkedin.com" or host.endswith(".linkedin.com"))
                or len(parts) != 2 or parts[0].casefold() != "company"
            ):
                return ""
            slug = observed_linkedin_ampersand_slug(parts[1])
            if not slug:
                return ""
        except (TypeError, ValueError):
            return ""
    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) != 2 or parts[0].casefold() != "company":
        return ""
    return slug


def is_linkedin_evidence_url(value: Any) -> bool:
    """Identify an absolute LinkedIn URL without accepting its claim."""

    if not isinstance(value, str) or value != value.strip():
        return False
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except (TypeError, ValueError):
        return False
    host = str(parsed.hostname or "").casefold()
    return (
        parsed.scheme.casefold() in {"http", "https"}
        and parsed.username is None
        and parsed.password is None
        and (port is None or 1 <= port <= 65535)
        and (host == "linkedin.com" or host.endswith(".linkedin.com"))
    )


def _canonical_company_domain(value: Any) -> str:
    """Return one normalized exact website host for identity comparison."""

    if not isinstance(value, str) or not value.strip():
        return ""
    raw = value.strip()
    if "://" not in raw:
        raw = "https://" + raw
    try:
        parsed = urlsplit(raw)
        port = parsed.port
    except ValueError:
        return ""
    host = str(parsed.hostname or "").casefold().rstrip(".").removeprefix("www.")
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        return ""
    if (
        parsed.scheme.casefold() not in {"http", "https"}
        or parsed.username is not None
        or parsed.password is not None
        or port not in {None, 80, 443}
        or "." not in host
    ):
        return ""
    return host


def _structured_company_domain_matches(
    requested_domain: Any,
    observed_website: Any,
) -> bool:
    """Match an exact host or a child of a requested registrable root."""

    requested = _canonical_company_domain(requested_domain)
    observed = _canonical_company_domain(observed_website)
    if not requested or not observed:
        return False
    if observed == requested:
        return True
    try:
        requested_parts = normalize_host(requested)
        observed_parts = normalize_host(observed)
    except NormalizationError:
        return False
    return (
        requested_parts.ascii_host == requested_parts.registrable_domain
        and observed_parts.registrable_domain
        == requested_parts.registrable_domain
        and observed_parts.ascii_host.endswith(
            "." + requested_parts.registrable_domain
        )
    )


def _strict_linkedin_company_profile_url(value: Any) -> str:
    """Return one canonical HTTPS LinkedIn company URL, or an empty string."""

    slug = linkedin_company_page_slug(value)
    if not slug or not isinstance(value, str) or value != value.strip():
        return ""
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        return ""
    host = str(parsed.hostname or "").casefold().rstrip(".")
    if (
        parsed.scheme.casefold() != "https"
        or (
            host not in {"linkedin.com", "www.linkedin.com"}
            and re.fullmatch(r"[a-z]{2}\.linkedin\.com", host) is None
        )
        or parsed.username is not None
        or parsed.password is not None
        or port not in {None, 443}
        or parsed.query
        or parsed.fragment
    ):
        return ""
    return f"https://www.linkedin.com/company/{slug}"


def _structured_company_elements(value: Any) -> list[Mapping[str, Any]]:
    current = value
    for _ in range(8):
        if not isinstance(current, Mapping):
            return []
        element = current.get("element")
        if isinstance(element, Mapping):
            if type(current.get("status")) is not int or current["status"] != 200:
                return []
            return [element]
        elements = current.get("elements")
        if isinstance(elements, list):
            if type(current.get("status")) is not int or current["status"] != 200:
                return []
            return [item for item in elements[:10] if isinstance(item, Mapping)]
        for key in ("toolResponse", "rawV2", "raw", "result", "data", "output"):
            child = current.get(key)
            if isinstance(child, Mapping) and child is not current:
                current = child
                break
        else:
            return []
    return []


def _structured_provider_reported_error(value: Any, *, depth: int = 0) -> bool:
    if not isinstance(value, Mapping) or depth > 5:
        return False
    if value.get("error") not in (None, "", False, [], {}):
        return True
    if value.get("errors") not in (None, "", False, [], {}):
        return True
    status = value.get("status")
    if type(status) is int and status >= 400:
        return True
    if str(status or "").casefold() in {
        "error",
        "failed",
        "failure",
    }:
        return True
    return any(
        _structured_provider_reported_error(value.get(key), depth=depth + 1)
        for key in ("toolResponse", "rawV2", "raw", "result", "data", "output")
    )


def _structured_profile_explicitly_not_found(value: Any) -> bool:
    """Recognize the requested profile's explicit absence, without credit."""
    current = value
    wrappers = ("toolResponse", "rawV2", "raw", "result", "data", "output")
    for _ in range(8):
        if not isinstance(current, Mapping):
            return False
        if (set(current) == {"error", "status", "element"}
            and current["error"] is None and type(current["status"]) is int
            and current["status"] == 404 and current["element"] is None):
            return True
        status = current.get("status")
        if ("status" in current and not (
            (type(status) is int and status == 200)
            or status in ("completed", "success")
        )) or ("job_id" in current and "status" not in current):
            return False
        # An outer account, request or job failure takes precedence over a
        # nested not-found payload. Empty/malformed success is not absence.
        if _structured_provider_reported_error({
            key: item for key, item in current.items() if key not in wrappers
        }):
            return False
        if sum(isinstance(current.get(key), Mapping) for key in wrappers) > 1:
            return False
        for key in wrappers:
            child = current.get(key)
            if isinstance(child, Mapping) and child is not current:
                current = child
                break
        else:
            return False
    return False


def _canonical_employee_range(value: Any) -> str:
    if not isinstance(value, Mapping):
        return ""
    start = value.get("start")
    end = value.get("end")
    if (
        isinstance(start, bool)
        or isinstance(end, bool)
        or not isinstance(start, int)
        or (end is not None and not isinstance(end, int))
    ):
        return ""
    return {
        (0, 1): "0-1",
        (2, 10): "2-10",
        (11, 50): "11-50",
        (51, 200): "51-200",
        (201, 500): "201-500",
        (501, 1_000): "501-1,000",
        (1_001, 5_000): "1,001-5,000",
        (5_001, 10_000): "5,001-10,000",
        (10_001, None): "10,001+",
    }.get((start, end), "")


def project_structured_linkedin_company_size(
    requested_domain: str,
    requested_profile_url: str,
    payload: Any,
) -> Optional[StructuredLinkedInCompanySizeEvidence]:
    """Project only an exact-identity canonical structured employee range."""

    domain = _canonical_company_domain(requested_domain)
    profile_url = _strict_linkedin_company_profile_url(requested_profile_url)
    requested_slug = linkedin_company_page_slug(profile_url)
    if not domain or not requested_slug or _structured_provider_reported_error(payload):
        return None
    for element in _structured_company_elements(payload):
        if not _structured_company_domain_matches(
            domain,
            element.get("website"),
        ):
            continue
        returned_profile = _strict_linkedin_company_profile_url(
            element.get("linkedinUrl") or element.get("linkedin_url")
        )
        if linkedin_company_page_slug(returned_profile) != requested_slug:
            continue
        employee_count = _canonical_employee_range(element.get("employeeCountRange"))
        if not employee_count:
            continue
        return {
            "employee_count": employee_count,
            "provider": STRUCTURED_PROFILE_PROVIDER,
            "source_field": STRUCTURED_PROFILE_SOURCE_FIELD,
            "url": profile_url,
            "website": f"https://{domain}/",
        }
    return None


def project_structured_linkedin_company_identity(
    requested_domain: str,
    requested_profile_url: str,
    payload: Any,
    *,
    observed_profile_url: str = "",
    expected_company_name: str = "",
    allow_website_redirect: bool = False,
    preserve_identity_website: bool = False,
) -> Optional[dict[str, str]]:
    """Project one exact main profile, including a proved numeric-ID alias."""

    domain = _canonical_company_domain(requested_domain)
    profile_url = _strict_linkedin_company_profile_url(requested_profile_url)
    requested_slug = linkedin_company_page_slug(profile_url)
    if not domain or not requested_slug or _structured_provider_reported_error(payload):
        return None
    elements = _structured_company_elements(payload)
    if len(elements) != 1:
        return None
    element = elements[0]
    returned_profile = _strict_linkedin_company_profile_url(
        element.get("linkedinUrl") or element.get("linkedin_url")
    )
    returned_slug = linkedin_company_page_slug(returned_profile)
    name = element.get("name")
    website_matches = _structured_company_domain_matches(
        domain, element.get("website")
    )
    if (
        not isinstance(name, str)
        or name != name.strip()
        or not name
        or len(name) > 200
        or any(ord(character) < 32 for character in name)
    ):
        return None
    if returned_slug == requested_slug:
        if not website_matches:
            return None
        return {
            "name": name,
            "provider": STRUCTURED_PROFILE_PROVIDER,
            "source_field": STRUCTURED_PROFILE_IDENTITY_SOURCE_FIELD,
            "url": profile_url,
            "website": f"https://{domain}/",
            **({"provider_website_url": element.get("website")}
               if preserve_identity_website else {}),
        }
    observed_profile = _strict_linkedin_company_profile_url(observed_profile_url)
    observed_slug = linkedin_company_page_slug(observed_profile)
    raw_company_id = element.get("id")
    if isinstance(raw_company_id, int) and not isinstance(raw_company_id, bool):
        company_id = str(raw_company_id)
    elif (
        isinstance(raw_company_id, str)
        and raw_company_id == raw_company_id.strip()
        and raw_company_id.isdigit()
    ):
        company_id = raw_company_id
    else:
        company_id = ""
    identity_name = name
    identity_source_field = STRUCTURED_PROFILE_IDENTITY_SOURCE_FIELD
    name_matches = _company_name(name) == _company_name(expected_company_name)
    if not name_matches:
        # One numeric main profile can publish a short display name and open
        # its own description with its full legal self-name. This is not a
        # search for customer/partner names elsewhere in provider prose.
        description = element.get("description")
        self_name = re.match(
            r"([A-Za-z0-9][A-Za-z0-9 .,'&()\-]{0,199}?)[ \t]+is[ \t]+([^\r\n]{1,300})",
            description,
        ) if isinstance(description, str) else None
        universal_name = element.get("universalName")
        if (
            website_matches
            and company_id.isascii()
            and self_name
            and name.isascii()
            and self_name[1].casefold().startswith(name.casefold() + " ")
            and _company_name(self_name[1]) == _company_name(expected_company_name)
            and isinstance(universal_name, str)
            and universal_name.isascii()
            and universal_name == returned_slug
            and re.match(r"(?:an?|the)[ \t]+[A-Za-z0-9]", self_name[2], re.I)
            and not re.search(
                r"\b(?:customers?|partners?|clients?|competitors?|subsidiar(?:y|ies)|division|"
                r"not|never|allegedly|quoted|mentioned)\b",
                self_name[2][:120], re.I,
            )
        ):
            identity_name = self_name[1]
            identity_source_field = "description.leading_legal_name"
            name_matches = True
    if (
        not requested_slug.isdigit()
        or company_id != requested_slug
        or not observed_slug
        or observed_slug.isdigit()
        or returned_profile != observed_profile
        or not name_matches
        or not _company_name(expected_company_name)
    ):
        return None
    evidence = {
        "name": identity_name,
        "provider": STRUCTURED_PROFILE_PROVIDER,
        "source_field": identity_source_field,
        "url": returned_profile,
        "website": f"https://{domain}/",
        "company_id": company_id,
        "requested_url": profile_url,
    }
    if website_matches:
        return evidence
    try:
        provider_website = public_http_url(element.get("website"))
    except (TypeError, ValueError):
        return None
    if not allow_website_redirect or urlsplit(provider_website).scheme != "https":
        return None
    evidence["provider_website_url"] = provider_website
    return evidence


def _firecrawl_data(payload: Any) -> Optional[Mapping[str, Any]]:
    current = payload
    for _ in range(8):
        if not isinstance(current, Mapping):
            return None
        if "rawHtml" in current or "metadata" in current:
            return current
        for key in ("toolResponse", "rawV2", "raw", "result", "data", "output"):
            child = current.get(key)
            if isinstance(child, Mapping) and child is not current:
                current = child
                break
        else:
            return None
    return None


async def _verified_provider_website_redirect(
    key: str,
    requested_domain: str,
    requested_url: str,
) -> str:
    """Return a Firecrawl-proved final URL on the verified company domain."""

    try:
        source_url = public_http_url(requested_url)
    except (TypeError, ValueError):
        return ""
    if source_url != requested_url or urlsplit(source_url).scheme != "https":
        return ""
    payload = {
        "url": source_url,
        "formats": ["rawHtml"],
        "onlyMainContent": False,
        "maxAge": 0,
        "timeout": 30_000,
        "storeInCache": False,
    }
    try:
        timeout = aiohttp.ClientTimeout(total=STRUCTURED_PROFILE_TIMEOUT_SECONDS)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                "https://code.deepline.com/api/v2/integrations/"
                "firecrawl_scrape/execute",
                json={"payload": payload},
                headers={
                    "Authorization": "Bearer " + key,
                    "Content-Type": "application/json",
                },
            ) as response:
                if response.status != 200:
                    return ""
                body = await response.json()
        data = _firecrawl_data(body)
        if data is None:
            return ""
        status, _headers, _raw, final_url = _firecrawl_response(
            SimpleNamespace(requested_parameters={"url": source_url}),
            data,
        )
    except (
        aiohttp.ClientError,
        aiohttp.ContentTypeError,
        asyncio.TimeoutError,
        CompatibilityResponseError,
        TypeError,
        ValueError,
    ):
        return ""
    return (
        final_url
        if status == 200
        and _structured_company_domain_matches(requested_domain, final_url)
        else ""
    )


def project_structured_linkedin_company_description(
    requested_domain: str,
    requested_profile_url: str,
    expected_company_name: str,
    payload: Any,
) -> Optional[StructuredLinkedInCompanyDescriptionEvidence]:
    """Project one bounded description for an exact structured identity."""

    identity = project_structured_linkedin_company_identity(
        requested_domain,
        requested_profile_url,
        payload,
    )
    elements = _structured_company_elements(payload)
    normalized_expected_name = _company_name(expected_company_name)
    normalized_observed_name = _company_name((identity or {}).get("name"))
    if (
        identity is None
        or len(elements) != 1
        or not normalized_expected_name
        or normalized_observed_name != normalized_expected_name
    ):
        return None
    description = elements[0].get("description")
    if (
        not isinstance(description, str)
        or not description
        or description != description.strip()
        or len(description) > PROFILE_MAX_CHARACTERS
        or any(
            unicodedata.category(character).startswith("C")
            and character not in "\t\n\r"
            for character in description
        )
    ):
        return None
    return {
        "name": identity["name"],
        "text": description,
        "provider": STRUCTURED_PROFILE_PROVIDER,
        "source_field": STRUCTURED_PROFILE_DESCRIPTION_SOURCE_FIELD,
        "url": identity["url"],
        "website": identity["website"],
    }


def project_structured_linkedin_company_headquarters(
    requested_domain: str,
    requested_profile_url: str,
    expected_company_name: str,
    payload: Any,
) -> Optional[dict[str, str]]:
    """Project one explicit HQ, never infer it from a branch or array order."""

    identity = project_structured_linkedin_company_identity(
        requested_domain, requested_profile_url, payload,
    )
    elements = _structured_company_elements(payload)
    if (
        identity is None
        or len(elements) != 1
        or not _company_name(expected_company_name)
        or _company_name(identity["name"]) != _company_name(expected_company_name)
    ):
        return None
    locations = elements[0].get("locations")
    if not isinstance(locations, list) or not 1 <= len(locations) <= 100:
        return None
    if any(
        not isinstance(location, Mapping)
        or ("headquarter" in location and type(location["headquarter"]) is not bool)
        for location in locations
    ):
        return None
    headquarters = [
        location for location in locations if location.get("headquarter") is True
    ]
    if len(headquarters) != 1:
        return None
    location = headquarters[0]
    parsed = location.get("parsed")
    if parsed is None:
        parsed = {}
    if not isinstance(parsed, Mapping):
        return None
    # Keep only bounded scalar geography. Reject contradictory parsed/raw facts.
    values = {
        "country": location.get("country"),
        "parsed_country": parsed.get("country"),
        "country_code": parsed.get("countryCode"),
        "country_full": parsed.get("countryFull"),
        "state": location.get("geographicArea"),
        "parsed_state": parsed.get("state"),
        "city": location.get("city"),
        "parsed_city": parsed.get("city"),
    }
    if any(
        value not in (None, "") and (
            not isinstance(value, str) or value != value.strip()
            or len(value) > 100
            or any(
                unicodedata.category(character).startswith("C")
                for character in value
            )
        )
        for value in values.values()
    ):
        return None
    countries = [
        values[key]
        for key in ("country", "parsed_country", "country_code", "country_full")
        if values[key]
    ]
    resolved_countries = {_resolve_country(value) for value in countries}
    if not countries or None in resolved_countries or len(resolved_countries) != 1:
        return None
    states = [values[key] for key in ("state", "parsed_state") if values[key]]
    country = (
        values["parsed_country"] or values["country_full"]
        or values["country"] or values["country_code"]
    )
    if len(country) in (2, 3) and country.isupper():
        country = next(iter(resolved_countries)).title()
    if resolved_countries == {"united states"}:
        resolved_states = {canonical_us_state(value) for value in states}
        if states and ("" in resolved_states or len(resolved_states) != 1):
            return None
    elif len({value.casefold() for value in states}) > 1:
        return None
    if (
        values["city"] and values["parsed_city"]
        and values["city"].casefold() != values["parsed_city"].casefold()
    ):
        return None
    state = values["parsed_state"] or values["state"]
    # Quote literal provider fields, not a server-authored headquarters claim.
    # The private projection retains the canonical website binding separately;
    # that website can have been independently canonicalized before this call.
    selected_location = {
        key: location[key]
        for key in ("headquarter", "country", "city", "geographicArea")
        if key in location
    }
    if "parsed" in location and location["parsed"] is not None:
        selected_location["parsed"] = {
            key: parsed[key]
            for key in ("country", "countryCode", "countryFull", "state", "city")
            if key in parsed
        }
    profile_field = "linkedinUrl" if elements[0].get("linkedinUrl") else "linkedin_url"
    text = json.dumps({
        "name": elements[0]["name"],
        profile_field: elements[0][profile_field],
        "locations": [selected_location],
    }, ensure_ascii=False, separators=(",", ":"))
    if len(text) > min(PROFILE_MAX_CHARACTERS, 2_000):
        return None
    return {
        "name": identity["name"], "text": text,
        "provider": STRUCTURED_PROFILE_PROVIDER,
        "source_field": STRUCTURED_PROFILE_HEADQUARTERS_SOURCE_FIELD,
        "url": identity["url"], "website": identity["website"],
        "country": country, "state": state or "",
    }


def project_structured_linkedin_public_company(
    requested_domain: str,
    requested_profile_url: str,
    payload: Any,
) -> Optional[StructuredLinkedInPublicCompanyEvidence]:
    """Project only an exact-identity structured Public Company value."""

    evidence = project_structured_linkedin_company_type(
        requested_domain,
        requested_profile_url,
        payload,
    )
    return (
        evidence
        if evidence is not None
        and evidence["company_type"] == STRUCTURED_PROFILE_PUBLIC_COMPANY_TYPE
        else None
    )


def project_structured_linkedin_company_type(
    requested_domain: str,
    requested_profile_url: str,
    payload: Any,
) -> Optional[StructuredLinkedInPublicCompanyEvidence]:
    """Project one exact-identity structured Public or Privately Held value."""

    domain = _canonical_company_domain(requested_domain)
    profile_url = _strict_linkedin_company_profile_url(requested_profile_url)
    requested_slug = linkedin_company_page_slug(profile_url)
    if not domain or not requested_slug or _structured_provider_reported_error(payload):
        return None
    for element in _structured_company_elements(payload):
        if not _structured_company_domain_matches(domain, element.get("website")):
            continue
        returned_profile = _strict_linkedin_company_profile_url(
            element.get("linkedinUrl") or element.get("linkedin_url")
        )
        if linkedin_company_page_slug(returned_profile) != requested_slug:
            continue
        company_type = element.get("companyType")
        if company_type not in {
            STRUCTURED_PROFILE_PUBLIC_COMPANY_TYPE,
            STRUCTURED_PROFILE_PRIVATE_COMPANY_TYPE,
        }:
            continue
        return {
            "company_type": company_type,
            "provider": STRUCTURED_PROFILE_PROVIDER,
            "source_field": STRUCTURED_PROFILE_COMPANY_TYPE_SOURCE_FIELD,
            "url": profile_url,
            "website": f"https://{domain}/",
        }
    return None


async def fetch_structured_linkedin_company_size(
    requested_domain: str,
    profile_url: str,
    *,
    diagnostic: Optional[dict[str, str]] = None,
    public_company_evidence: Optional[dict[str, str]] = None,
    company_identity_evidence: Optional[dict[str, str]] = None,
    company_identity_observed_profile_url: str = "",
    company_description_evidence: Optional[dict[str, str]] = None,
    company_headquarters_evidence: Optional[dict[str, str]] = None,
    expected_company_name: str = "",
    preserve_identity_website: bool = False,
) -> Optional[StructuredLinkedInCompanySizeEvidence]:
    """Fetch one profile and project size plus optional company-type evidence."""

    key = str(os.environ.get("DEEPLINE_API_KEY") or "").strip()
    canonical_profile = _strict_linkedin_company_profile_url(profile_url)
    domain = _canonical_company_domain(requested_domain)
    if not key:
        return None
    if not canonical_profile or not domain:
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    try:
        timeout = aiohttp.ClientTimeout(total=STRUCTURED_PROFILE_TIMEOUT_SECONDS)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                "https://code.deepline.com/api/v2/integrations/"
                "harvestapi_get_company/execute",
                json={"payload": {"url": canonical_profile}},
                headers={
                    "Authorization": "Bearer " + key,
                    "Content-Type": "application/json",
                },
            ) as response:
                if response.status != 200:
                    _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
                    return None
                try:
                    body = await response.json()
                except (aiohttp.ContentTypeError, ValueError):
                    _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
                    return None
    except (aiohttp.ClientError, asyncio.TimeoutError):
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    except Exception:  # noqa: BLE001
        _set_failure_reason(diagnostic, UNEXPECTED_VERIFIER_ERROR_FAILURE_REASON)
        return None
    if _structured_profile_explicitly_not_found(body):
        # A completed exact-profile lookup found no profile. Keep the
        # caller's insufficient-evidence outcome; supply no identity or size.
        return None
    if _structured_provider_reported_error(body):
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    if not _structured_company_elements(body):
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    identity_evidence = project_structured_linkedin_company_identity(
        domain,
        canonical_profile,
        body,
        observed_profile_url=company_identity_observed_profile_url,
        expected_company_name=expected_company_name,
        allow_website_redirect=bool(company_identity_observed_profile_url),
        preserve_identity_website=preserve_identity_website,
    )
    projection_body = body
    # Only a numeric profile alias can authorize the existing redirect lookup.
    # Retaining a website for identity proof must not add a provider request.
    provider_website_url = str(
        (identity_evidence or {}).get("provider_website_url") or ""
    ) if (identity_evidence or {}).get("requested_url") else ""
    if provider_website_url:
        final_url = await _verified_provider_website_redirect(
            key,
            domain,
            provider_website_url,
        )
        if final_url:
            identity_evidence = dict(identity_evidence or {})
            identity_evidence.update(
                provider_website_requested_url=provider_website_url,
                provider_website_final_url=final_url,
            )
            projection_body = {
                "status": 200,
                "element": {
                    **dict(_structured_company_elements(body)[0]),
                    "website": f"https://{domain}/",
                },
            }
        else:
            identity_evidence = None
    projected_profile = (
        str(identity_evidence.get("url") or "")
        if isinstance(identity_evidence, Mapping)
        else canonical_profile
    )
    public_evidence = project_structured_linkedin_company_type(
        domain,
        projected_profile,
        projection_body,
    )
    if public_company_evidence is not None and public_evidence is not None:
        public_company_evidence.update(public_evidence)
    if company_identity_evidence is not None and identity_evidence is not None:
        company_identity_evidence.update(identity_evidence)
    description_evidence = project_structured_linkedin_company_description(
        domain,
        projected_profile,
        expected_company_name,
        projection_body,
    )
    if (
        company_description_evidence is not None
        and description_evidence is not None
    ):
        company_description_evidence.update(description_evidence)
    headquarters_evidence = project_structured_linkedin_company_headquarters(
        domain, projected_profile, expected_company_name, projection_body,
    )
    if (
        company_headquarters_evidence is not None
        and headquarters_evidence is not None
    ):
        company_headquarters_evidence.update(headquarters_evidence)
    evidence = project_structured_linkedin_company_size(
        domain,
        projected_profile,
        projection_body,
    )
    if evidence is None:
        # A valid one-company reply that lacks the requested exact identity or
        # canonical range is local to this profile. Arena may retry it, then
        # isolate only this company instead of cancelling the scoring item.
        _set_failure_reason(diagnostic, SOURCE_BLOCKED_FAILURE_REASON)
    return evidence


def _is_linkedin_access_wall(text: str) -> bool:
    """Return whether exact-profile text is an authentication or block wall."""

    visible_lines = [
        line.strip().lstrip("#").strip().casefold()
        for line in text[:PROFILE_MAX_CHARACTERS].splitlines()
        if line.strip()
    ]
    top_lines = visible_lines[:4]
    folded = "\n".join(visible_lines)
    blocked_body = "\n".join(
        line for line in visible_lines if line not in _BLOCKED_PAGE_TITLES
    )
    authentication_wall = (
        any(line in _ACCESS_WALL_TITLES for line in top_lines)
        and any(
            all(field.casefold() in folded for field in fields)
            for fields in _ACCESS_WALL_CREDENTIAL_FIELDS
        )
    )
    blocked_page = (
        any(line in _BLOCKED_PAGE_TITLES for line in top_lines)
        and any(marker in blocked_body for marker in _BLOCKED_PAGE_MARKERS)
    )
    return authentication_wall or blocked_page


def _canonical_linkedin_company_size(value: str) -> Optional[str]:
    """Map an exact English, Dutch, or Portuguese band to canonical form."""

    raw = _EMPLOYEE_SUFFIX.sub("", value.strip().strip("*").strip())
    for band in LINKEDIN_EMPLOYEE_BUCKETS:
        localized = re.escape(band)
        localized = localized.replace(r"\-", r"\s*[-\u2013]\s*")
        localized = localized.replace(",", r"[,.]")
        if re.fullmatch(localized, raw, re.IGNORECASE):
            return band
    return None


def extract_linkedin_company_size(text: Any) -> Optional[dict[str, str]]:
    """Extract only LinkedIn's literal Company size field from About."""

    if not isinstance(text, str):
        return None
    lines = text[:PROFILE_MAX_CHARACTERS].splitlines()
    about_start: Optional[int] = None
    about_end = len(lines)
    for index, line in enumerate(lines):
        visible = line.strip().strip("*").strip()
        if about_start is None:
            if _ABOUT_SECTION_HEADING.fullmatch(visible):
                about_start = index + 1
            continue
        if _ABOUT_SECTION_END_HEADING.fullmatch(visible):
            about_end = index
            break
    if about_start is None:
        return None

    for index in range(about_start, about_end):
        field_match = _COMPANY_SIZE_FIELD.fullmatch(lines[index].strip())
        if field_match is None:
            continue
        raw_value = str(field_match.group("value") or "").strip().strip("*").strip()
        quote_end = index
        if not raw_value:
            for next_index in range(index + 1, min(about_end, index + 4)):
                candidate = lines[next_index].strip().strip("*").strip()
                if candidate:
                    raw_value = candidate
                    quote_end = next_index
                    break
        employee_count = _canonical_linkedin_company_size(raw_value)
        if employee_count is None:
            return None
        quote = "\n".join(lines[index : quote_end + 1]).strip()
        if not quote:
            return None
        return {
            "employee_count": employee_count,
            "quote": quote[:500],
        }
    return None


def _profile_body_matches_company_identity(
    text: str, identity: Mapping[str, Any],
) -> bool:
    """Bind the profile's own website or title, never a name mentioned in prose."""

    domain = _canonical_company_domain(identity.get("registrable_dns_domain"))
    names = {
        _company_name(identity.get("normalized_name")),
        _company_name(verified_homepage_brand_name(identity)),
    }
    aliases = identity.get("verified_legal_name_aliases")
    if isinstance(aliases, list):
        names.update(_company_name(value) for value in aliases[:3])
    names.discard("")
    if not domain or not names:
        return False
    lines = text[:PROFILE_MAX_CHARACTERS].splitlines()
    before_about: list[str] = []
    about_lines: list[str] = []
    in_about = False
    for line in lines:
        visible = line.strip().strip("*").strip()
        if _ABOUT_SECTION_HEADING.fullmatch(visible):
            in_about = True
            continue
        if in_about:
            if _ABOUT_SECTION_END_HEADING.fullmatch(visible):
                break
            about_lines.append(visible)
        elif visible:
            before_about.append(visible)
    # The labelled profile website is a stronger binding than a display name,
    # which may use a legal name or tagline. An explicit different website must
    # not be overridden by a matching name elsewhere on the page.
    websites: list[str] = []
    for index, line in enumerate(about_lines):
        match = re.fullmatch(
            r"(?:Website|Site web|Site)(?:\s*:\s*|\s+|$)(.*)",
            line.replace("**", ""), re.I,
        )
        if not match:
            continue
        value = match.group(1).strip()
        if not value:
            value = next(
                (value for value in about_lines[index + 1:index + 4] if value), "",
            )
        markdown = re.fullmatch(r"\[[^\]]*\]\((https?://[^\s)]+)\)", value)
        value = markdown.group(1) if markdown else value
        websites.append(value)
    if websites:
        return all(
            _structured_company_domain_matches(domain, value) for value in websites
        )
    # Accept only the profile title or heading before About. A customer, partner,
    # or expected company named in the description cannot bind this profile.
    for line in before_about[:10]:
        heading = re.fullmatch(r"#\s+(.+)", line)
        title = re.fullmatch(r"(.+?)\s*\|\s*LinkedIn", line, re.I)
        if heading or title:
            name = (title or heading).group(1)
            name = re.sub(r"\s*\|\s*LinkedIn\s*$", "", name, flags=re.I)
            return _company_name(name) in names
    return False


async def fetch_current_linkedin_company_size(
    profile_url: str,
    *,
    diagnostic: Optional[dict[str, str]] = None,
    source_text_sink: Optional[dict[str, str]] = None,
    expected_company_identity: Optional[Mapping[str, Any]] = None,
) -> Optional[CurrentLinkedInCompanySizeResult]:
    """Return exact size proof, explicit no-size content, or retryable failure.

    A successful exact-profile About result with no canonical Company size, or
    the provider's exact-profile ``CRAWL_NOT_FOUND`` result, returns the explicit
    insufficient-evidence outcome. Authentication or block walls, transport
    failures, other status failures, and malformed results return ``None``.
    An optional caller-owned sink receives one bounded safe response body or
    exact-source absence metadata; neither enters public results or diagnostics.
    When an independent expected identity is supplied, the profile body must
    bind that company before its employee range can become size evidence. A
    missing or different body identity is insufficient evidence, not a provider
    failure; the raw body remains available for separate investigation.
    """

    requested_slug = linkedin_company_page_slug(profile_url)
    key = str(os.environ.get("EXA_API_KEY") or "").strip()
    if not requested_slug or not key:
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    payload = {
        "ids": [profile_url],
        "text": {"maxCharacters": PROFILE_MAX_CHARACTERS},
        "maxAgeHours": 0,
        "livecrawlTimeout": PROFILE_LIVECRAWL_TIMEOUT_MILLISECONDS,
    }
    try:
        timeout = aiohttp.ClientTimeout(total=PROFILE_TIMEOUT_SECONDS)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                "https://api.exa.ai/contents",
                json=payload,
                headers={"x-api-key": key, "Content-Type": "application/json"},
            ) as response:
                if response.status != 200:
                    logger.warning(
                        "current_linkedin_size_unavailable status=%s",
                        response.status,
                    )
                    _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
                    return None
                try:
                    body = await response.json()
                except (aiohttp.ContentTypeError, ValueError) as exc:
                    logger.warning(
                        "current_linkedin_size_unavailable error=%s",
                        type(exc).__name__,
                    )
                    _set_failure_reason(
                        diagnostic, MALFORMED_RESPONSE_FAILURE_REASON
                    )
                    return None
    except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
        logger.warning(
            "current_linkedin_size_unavailable error=%s",
            type(exc).__name__,
        )
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "current_linkedin_size_unavailable error=%s",
            type(exc).__name__,
        )
        _set_failure_reason(diagnostic, UNEXPECTED_VERIFIER_ERROR_FAILURE_REASON)
        return None
    if not isinstance(body, Mapping):
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    if (
        body.get("error")
        or body.get("errors")
        or str(body.get("status") or "").casefold()
        in {"error", "failed", "failure"}
    ):
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    statuses = body.get("statuses")
    results = body.get("results")
    if isinstance(statuses, list) and len(statuses) == 1:
        status_item = statuses[0]
        status_error = (
            status_item.get("error")
            if isinstance(status_item, Mapping)
            and isinstance(status_item.get("error"), Mapping)
            else {}
        )
        status_slug = (
            linkedin_company_page_slug(status_item.get("id"))
            if isinstance(status_item, Mapping)
            else ""
        )
        if (
            isinstance(status_item, Mapping)
            and str(status_item.get("status") or "").casefold() == "error"
            and type(status_error.get("httpStatusCode")) is int
            and status_error["httpStatusCode"] in {404, 410}
            and status_error.get("tag") == "CRAWL_NOT_FOUND"
            and status_slug == requested_slug
            and _strict_linkedin_company_profile_url(profile_url)
            and _strict_linkedin_company_profile_url(status_item.get("id"))
            == _strict_linkedin_company_profile_url(profile_url)
            and results == []
        ):
            if isinstance(source_text_sink, dict):
                # Retain only this exact requested source's explicit absence.
                # The investigator must not turn it into an empty-page fault.
                source_text_sink.clear()
                source_text_sink.update({
                    "url": str(status_item["id"]), "text": "",
                    "http_status": str(status_error["httpStatusCode"]),
                })
            return {
                "outcome": CURRENT_LINKEDIN_SIZE_INSUFFICIENT_EVIDENCE,
                "url": str(status_item["id"]),
            }
        if (
            isinstance(status_item, Mapping)
            and str(status_item.get("status") or "").casefold() == "error"
            and status_error.get("httpStatusCode") == 409
            and status_error.get("tag") == "CRAWL_NON_CANONICAL"
            and status_slug == requested_slug
            and results == []
        ):
            # Exa classified this exact profile as noncanonical. This is
            # source-local, like an authentication wall, rather than evidence
            # that the Exa account is unavailable.
            _set_failure_reason(diagnostic, SOURCE_BLOCKED_FAILURE_REASON)
            return None
        if (
            isinstance(status_item, Mapping)
            and str(status_item.get("status") or "").casefold() == "error"
            and status_error.get("httpStatusCode") == 504
            and status_error.get("tag") == "CRAWL_LIVECRAWL_TIMEOUT"
            and status_slug == requested_slug
            and results == []
        ):
            # Exa could not live-crawl this exact profile within its bounded
            # source timeout. Other Exa or outer HTTP failures stay systemic.
            _set_failure_reason(diagnostic, SOURCE_BLOCKED_FAILURE_REASON)
            return None
    if statuses is not None and (
        not isinstance(statuses, list)
        or not statuses
        or any(
            not isinstance(item, Mapping)
            or str(item.get("status") or "").casefold() != "success"
            for item in statuses
        )
    ):
        if isinstance(statuses, list) and any(
            isinstance(item, Mapping)
            and str(item.get("status") or "").casefold() == "error"
            for item in statuses
        ):
            _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        else:
            _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    result = results[0] if isinstance(results, list) and len(results) == 1 else None
    if (
        not isinstance(result, Mapping)
    ):
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    if (
        result.get("error")
        or result.get("errors")
        or str(result.get("status") or "").casefold()
        in {"error", "failed", "failure"}
    ):
        _set_failure_reason(diagnostic, PROVIDER_ERROR_FAILURE_REASON)
        return None
    returned_url = result.get("url")
    returned_slug = linkedin_company_page_slug(returned_url)
    if not isinstance(returned_url, str) or not returned_slug:
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    if returned_slug != requested_slug:
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    text = result.get("text")
    if not isinstance(text, str):
        _set_failure_reason(diagnostic, MALFORMED_RESPONSE_FAILURE_REASON)
        return None
    if _is_linkedin_access_wall(text):
        _set_failure_reason(diagnostic, SOURCE_BLOCKED_FAILURE_REASON)
        return None
    try:
        returned_parts = urlsplit(returned_url)
        returned_port = returned_parts.port
    except (TypeError, ValueError):
        returned_parts = None
        returned_port = None
    if (
        isinstance(source_text_sink, dict)
        and returned_parts is not None
        and returned_parts.scheme == "https"
        and returned_parts.username is None
        and returned_parts.password is None
        and not returned_parts.fragment
        and (returned_port is None or returned_port == 443)
        and returned_url == returned_url.strip()
        and len(returned_url) <= 2_000
        and returned_url.isascii()
        and not any(character.isspace() for character in returned_url)
        and text
        and len(text) <= PROFILE_MAX_CHARACTERS
    ):
        # Private caller-owned evidence only. The raw body never enters the
        # typed result, diagnostic, receipt, or model-facing JSON.
        source_text_sink.clear()
        source_text_sink.update({"url": returned_url, "text": text})
    extracted = extract_linkedin_company_size(text)
    if (
        expected_company_identity is not None
        and not _profile_body_matches_company_identity(text, expected_company_identity)
    ):
        extracted = None
    if extracted is None:
        return {
            "outcome": CURRENT_LINKEDIN_SIZE_INSUFFICIENT_EVIDENCE,
            "url": returned_url,
        }
    return {**extracted, "url": returned_url}
