"""Three-state company-fit decision contract.

The stable named result prevents non-empty decision strings from becoming
accidental truthy passes across qualification consumers.
"""

from __future__ import annotations

import copy
import re
from typing import Any, Final, Iterable, Literal, Mapping, Optional
from urllib.parse import quote, unquote, urlsplit


COMPANY_FIT_DECISION_CONTRACT_ID: Final = "company-fit-decision:v1"
COMPANY_FIT_DECISION_VERSION = COMPANY_FIT_DECISION_CONTRACT_ID
COMPANY_FIT_DECISIONS: Final = ("match", "mismatch", "unavailable")
COMPANY_FIT_DECISION_PRECEDENCE: Final = (
    "mismatch",
    "unavailable",
    "match",
)
COMPANY_FIT_PASSING_OUTCOME: Final = "match"
COMPANY_FIT_REQUIRED_DIMENSIONS: Final = (
    "identity",
    "employee_size",
    "industry",
    "geography",
)
COMPANY_FIT_CONDITIONAL_DIMENSIONS: Final = ("stage",)
COMPANY_FIT_DIMENSIONS: Final = (
    *COMPANY_FIT_REQUIRED_DIMENSIONS,
    *COMPANY_FIT_CONDITIONAL_DIMENSIONS,
)
COMPANY_FIT_MATCH = "match"
COMPANY_FIT_MISMATCH = "mismatch"
COMPANY_FIT_UNAVAILABLE = "unavailable"

CompanyFitDecision = Literal["match", "mismatch", "unavailable"]

_LEGAL_SUFFIXES: Final = frozenset({
    "incorporated", "corporation", "company", "limited", "holdings",
    "group", "inc", "corp", "co", "llc", "llp", "ltd", "plc", "gmbh",
    "ag", "sa", "nv", "bv", "oy", "ab", "as", "pty", "pte",
    "kk", "srl", "spa",
})
_LINKEDIN_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9._%+-]{0,99}$")
_PARENTHETICAL_INITIALISM_RE = re.compile(
    r"^\s*(?P<legal_name>.+?)\s*\(\s*(?P<initialism>[A-Z0-9]{2,10})\s*\)\s*$"
)
_INDEPENDENT_IDENTITY_SOURCES: Final = frozenset({
    "company_homepage",
    "company_web_reverification",
})


def company_fit_decision_contract_identity() -> dict[str, object]:
    """Return the model-owned compatibility identity."""

    return {
        "contract_id": COMPANY_FIT_DECISION_CONTRACT_ID,
        "outcomes": list(COMPANY_FIT_DECISIONS),
        "precedence": list(COMPANY_FIT_DECISION_PRECEDENCE),
        "passing_outcome": COMPANY_FIT_PASSING_OUTCOME,
        "required_dimensions": list(COMPANY_FIT_REQUIRED_DIMENSIONS),
        "conditional_dimensions": list(COMPANY_FIT_CONDITIONAL_DIMENSIONS),
    }


def reconcile_company_fit_decisions(decisions: Iterable[Any]) -> str:
    """Apply model-owned mismatch-first decision precedence."""

    normalized = [
        value.strip().casefold() if isinstance(value, str) else ""
        for value in decisions
    ]
    if not normalized:
        return COMPANY_FIT_UNAVAILABLE
    if COMPANY_FIT_MISMATCH in normalized:
        return COMPANY_FIT_MISMATCH
    if any(value != COMPANY_FIT_MATCH for value in normalized):
        return COMPANY_FIT_UNAVAILABLE
    return COMPANY_FIT_MATCH


def aggregate_company_fit_decisions(
    decisions: Mapping[str, Any],
    *,
    stage_required: bool = False,
) -> str:
    """Aggregate a complete dimension map using the model-owned contract."""

    if not isinstance(decisions, Mapping) or not decisions:
        return COMPANY_FIT_UNAVAILABLE
    required = set(COMPANY_FIT_REQUIRED_DIMENSIONS)
    if stage_required:
        required.add("stage")
    values = [
        decisions.get(dimension, COMPANY_FIT_UNAVAILABLE)
        for dimension in required
    ]
    if any(key not in COMPANY_FIT_DIMENSIONS for key in decisions):
        values.append(COMPANY_FIT_UNAVAILABLE)
    return reconcile_company_fit_decisions(values)


def strict_company_fit_boolean(value: Any) -> Optional[bool]:
    """Accept only an actual JSON Boolean."""

    return value if isinstance(value, bool) else None


def _canonical_domain(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw or any(character.isspace() for character in raw):
        return ""
    if "://" not in raw and not raw.startswith("//"):
        raw = f"//{raw}"
    try:
        parsed = urlsplit(raw)
    except ValueError:
        return ""
    if parsed.username or parsed.password:
        return ""
    host = (parsed.hostname or "").casefold().removeprefix("www.")
    if not host or "." not in host or host.endswith(".") or ":" in host:
        return ""
    try:
        return host.encode("idna").decode("ascii")
    except UnicodeError:
        return ""


def observed_linkedin_ampersand_slug(value: str) -> str:
    """Canonicalize one observed path component, without miner admission."""

    slug = unquote(value).casefold()
    if (
        "&" not in slug
        or re.fullmatch(r"[a-z0-9][a-z0-9_.&-]{0,99}", slug, re.ASCII) is None
    ):
        return ""
    return quote(slug, safe="._-")


def _linkedin_slug(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if "://" not in raw:
        raw = f"https://{raw}"
    try:
        parsed = urlsplit(raw)
    except ValueError:
        return ""
    host = (parsed.hostname or "").casefold().removeprefix("www.")
    parts = [part for part in parsed.path.split("/") if part]
    if (
        not (host == "linkedin.com" or host.endswith(".linkedin.com"))
        or len(parts) < 2
        or parts[0].casefold() != "company"
    ):
        return ""
    slug = parts[1].casefold()
    ampersand_slug = observed_linkedin_ampersand_slug(slug)
    if ampersand_slug:
        return ampersand_slug
    return slug if _LINKEDIN_SLUG_RE.fullmatch(slug) else ""


def _company_name(value: Any) -> str:
    """Normalize a company name after removing terminal legal suffixes only.

    Some legal-looking tokens are also real leading name terms: ``Group Nine
    Media`` and ``AG Grid`` must not collapse into different companies merely
    because ``group`` and ``ag`` can occur as legal suffixes elsewhere.
    """

    words = re.findall(r"[a-z0-9]+", str(value or "").casefold())
    while words:
        if len(words) > 3 and words[-3:] == ["public", "limited", "company"]:
            del words[-3:]
        elif words[-1] in _LEGAL_SUFFIXES:
            words.pop()
        else:
            break
    return "".join(words)


def verified_homepage_brand_name(identity: Mapping[str, Any]) -> str:
    """Read the host-projected brand bound to this exact homepage legal name.

    Callers supply an independently verified homepage anchor, never model JSON.
    A brand cannot extend an unrelated legal identity merely by being present.
    """

    brand = identity.get("verified_brand_name")
    aliases = identity.get("verified_legal_name_aliases")
    name = _company_name(identity.get("normalized_name"))
    if (
        not isinstance(brand, str)
        or not 2 < len(brand.strip()) <= 200
        or not _company_name(brand)
        or not name
        or not isinstance(aliases, list)
        or not aliases
    ):
        return ""
    if name == _company_name(brand) or any(
        isinstance(alias, str) and len(alias.strip()) <= 200
        and _company_name(alias) == name
        for alias in aliases[:3]
    ):
        return brand.strip()
    return ""


def _verified_parenthetical_name_alignment(
    submitted_name: Any,
    observed_name: Any,
    *,
    observed_linkedin_slug: str,
    evidence_source: str,
) -> bool:
    """Recognize an explicit legal-name/common-initialism pair.

    This narrow bridge applies only to independently observed identity evidence
    on the exact submitted domain. It does not infer unstated or fuzzy aliases.
    """

    if (
        not observed_linkedin_slug
        or evidence_source not in _INDEPENDENT_IDENTITY_SOURCES
    ):
        return False
    match = _PARENTHETICAL_INITIALISM_RE.fullmatch(
        str(submitted_name or "").strip()
    )
    if match is None:
        return False

    initialism = match.group("initialism").casefold()
    if observed_linkedin_slug != initialism:
        return False
    return _company_name(match.group("legal_name")) == _company_name(observed_name)


def evaluate_company_identity(
    *,
    submitted_name: Any,
    submitted_website: Any,
    submitted_linkedin: Any,
    observed_name: Any,
    observed_website: Any,
    observed_linkedin: Any = "",
    evidence_source: Any = "",
    company_quality: bool = False,
) -> dict[str, str]:
    """Bind the submitted name, website, and LinkedIn to one observed entity."""

    submitted_linkedin_raw = str(submitted_linkedin or "").strip()
    submitted = {
        "name": _company_name(submitted_name),
        "domain": _canonical_domain(submitted_website),
        "linkedin_slug": _linkedin_slug(submitted_linkedin),
    }
    observed = {
        "name": _company_name(observed_name),
        "domain": _canonical_domain(observed_website),
        "linkedin_slug": _linkedin_slug(observed_linkedin),
    }
    source = str(evidence_source or "").strip().casefold()
    receipt = {
        "decision": "unavailable",
        "reason_code": "identity_not_proven",
        "submitted_name": submitted["name"],
        "submitted_domain": submitted["domain"],
        "submitted_linkedin_slug": submitted["linkedin_slug"],
        "observed_name": observed["name"],
        "observed_domain": observed["domain"],
        "observed_linkedin_slug": observed["linkedin_slug"],
        "evidence_source": source,
    }
    if not submitted["name"] or not submitted["domain"]:
        receipt.update(decision="mismatch", reason_code="identity_unresolved")
        return receipt
    if submitted_linkedin_raw and not submitted["linkedin_slug"]:
        receipt.update(decision="mismatch", reason_code="identity_unresolved")
        return receipt
    if not observed["name"] or not observed["domain"]:
        return receipt
    if observed["domain"] != submitted["domain"]:
        receipt.update(decision="mismatch", reason_code="identity_mismatch")
        return receipt
    if submitted["linkedin_slug"] and not observed["linkedin_slug"]:
        return receipt
    if (
        submitted["linkedin_slug"]
        and observed["linkedin_slug"] != submitted["linkedin_slug"]
    ):
        # LinkedIn may expose an opaque numeric company ID on a first-party
        # homepage while the submitted record has the company's vanity slug.
        # Those two identifiers do not prove a conflict by themselves; a later
        # independently grounded web receipt can still bind the entity.
        if observed["linkedin_slug"].isdigit() != submitted["linkedin_slug"].isdigit():
            receipt.update(reason_code="identity_linkedin_alias_unresolved")
            return receipt
        # A first-party homepage can retain an old vanity URL after LinkedIn
        # renames the company page. Exact name and domain evidence make this an
        # unresolved alias, not proof of a different entity. The later web
        # verifier must still bind the submitted current slug independently.
        if (
            source == "company_homepage"
            and observed["name"] == submitted["name"]
            and observed["linkedin_slug"]
            and not observed["linkedin_slug"].isdigit()
        ):
            receipt.update(reason_code="identity_linkedin_alias_unresolved")
            return receipt
        receipt.update(decision="mismatch", reason_code="identity_mismatch")
        return receipt
    if observed["name"] != submitted["name"]:
        parenthetical_names_align = _verified_parenthetical_name_alignment(
            submitted_name,
            observed_name,
            observed_linkedin_slug=observed["linkedin_slug"],
            evidence_source=source,
        )
        if company_quality and not parenthetical_names_align:
            # Exact domain/LinkedIn agreement can show that both observations
            # point at one entity, but it cannot invent an unstated legal-name
            # or brand alias.  The caller may still resolve the alias from an
            # explicit, independently verified homepage identity record.
            receipt.update(reason_code="identity_name_alias_unresolved")
            return receipt
        # A matching registrable domain with a different common/legal name is
        # not proof of a conflict by itself. Keep the result unavailable when
        # there is no second stable identifier to bind the alias.
        if submitted["linkedin_slug"]:
            if not parenthetical_names_align:
                # Select both names even when their lengths are equal. Separate
                # min/max calls choose the same first item on a length tie.
                shorter_name, longer_name = sorted(
                    (submitted["name"], observed["name"]),
                    key=len,
                )
                if (
                    len(shorter_name) < 4
                    or not longer_name.startswith(shorter_name)
                ):
                    receipt.update(
                        decision="mismatch",
                        reason_code="identity_mismatch",
                    )
                    return receipt
        elif source != "company_homepage" or not parenthetical_names_align:
            return receipt
    receipt.update(decision="match", reason_code="verifier_accepted")
    return receipt


def company_quality_receipt_matches_claim(
    receipt: Any,
    company: Mapping[str, Any],
) -> bool:
    """Validate that a quality receipt is canonical and binds this exact claim."""

    if (
        not isinstance(receipt, Mapping)
        or not isinstance(company, Mapping)
        or receipt.get("decision") != COMPANY_FIT_MATCH
        or receipt.get("evidence_source") not in _INDEPENDENT_IDENTITY_SOURCES
    ):
        return False
    claimed_name = _company_name(company.get("company_name"))
    claimed_domain = _canonical_domain(company.get("company_website"))
    claimed_linkedin_slug = _linkedin_slug(company.get("company_linkedin"))
    if (
        not claimed_name
        or not claimed_domain
        or not claimed_linkedin_slug
        or receipt.get("submitted_name") != claimed_name
        or receipt.get("submitted_domain") != claimed_domain
        or receipt.get("submitted_linkedin_slug") != claimed_linkedin_slug
    ):
        return False

    raw_observed_name = receipt.get("observed_name")
    raw_observed_domain = receipt.get("observed_domain")
    raw_observed_linkedin_slug = receipt.get("observed_linkedin_slug")
    if any(
        not isinstance(value, str) or not value.strip()
        for value in (
            raw_observed_name,
            raw_observed_domain,
            raw_observed_linkedin_slug,
        )
    ):
        return False
    observed_name = _company_name(raw_observed_name)
    observed_domain = _canonical_domain(raw_observed_domain)
    observed_linkedin_slug = _linkedin_slug(
        "https://www.linkedin.com/company/"
        f"{raw_observed_linkedin_slug}"
    )
    if (
        raw_observed_name != observed_name
        or raw_observed_domain != observed_domain
        or raw_observed_linkedin_slug != observed_linkedin_slug
    ):
        return False

    evaluated = evaluate_company_identity(
        submitted_name=company.get("company_name"),
        submitted_website=company.get("company_website"),
        submitted_linkedin=company.get("company_linkedin"),
        observed_name=observed_name,
        observed_website=f"https://{observed_domain}",
        observed_linkedin=(
            "https://www.linkedin.com/company/"
            f"{observed_linkedin_slug}"
        ),
        evidence_source=receipt.get("evidence_source"),
        company_quality=True,
    )
    if evaluated.get("decision") == COMPANY_FIT_MATCH:
        return True
    if evaluated.get("reason_code") != "identity_name_alias_unresolved":
        return False

    raw_aliases = receipt.get("verified_legal_name_aliases")
    if not isinstance(raw_aliases, list) or len(raw_aliases) > 3:
        return False
    if receipt.get("reason_code") == "verified_homepage_brand_alias":
        brand = verified_homepage_brand_name({
            "normalized_name": claimed_name,
            "verified_brand_name": receipt.get("verified_brand_name"),
            "verified_legal_name_aliases": raw_aliases,
        })
        return bool(
            receipt.get("evidence_source") == "company_web_reverification"
            and receipt.get("verified_homepage_brand_alias") is True
            and brand and _company_name(brand) == observed_name
            and raw_aliases
            and all(
                isinstance(alias, str) and alias.strip() and len(alias.strip()) <= 200
                and _company_name(alias) == claimed_name
                for alias in raw_aliases
            )
        )
    return any(
        isinstance(alias, str)
        and bool(alias.strip())
        and len(alias.strip()) <= 200
        and _company_name(alias) == observed_name
        for alias in raw_aliases
    )


class CompanyFitDecisionResult:
    """One company-fit decision with named state and evidence."""

    def __init__(
        self,
        decision: CompanyFitDecision,
        reason: Optional[str] = None,
        *,
        details: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if decision not in {
            COMPANY_FIT_MATCH,
            COMPANY_FIT_MISMATCH,
            COMPANY_FIT_UNAVAILABLE,
        }:
            raise ValueError(f"invalid company fit decision: {decision!r}")
        self.decision = decision
        self._passed = decision == COMPANY_FIT_MATCH
        self._reason = reason
        self.details = copy.deepcopy(dict(details or {}))

    @property
    def passed(self) -> bool:
        return self._passed

    @property
    def reason(self) -> Optional[str]:
        return self._reason

    def __bool__(self) -> bool:
        return self.passed

    def receipt(self, gate: str) -> dict:
        receipt = {
            "gate": str(gate),
            "contract_id": COMPANY_FIT_DECISION_CONTRACT_ID,
            "contract_version": COMPANY_FIT_DECISION_VERSION,
            "decision": self.decision,
            "reason": self.reason,
        }
        receipt.update(self.details)
        return receipt


def company_fit_match(
    reason: Optional[str] = None,
    *,
    details: Optional[Mapping[str, Any]] = None,
) -> CompanyFitDecisionResult:
    return CompanyFitDecisionResult(COMPANY_FIT_MATCH, reason, details=details)


def company_fit_mismatch(
    reason: Optional[str],
    *,
    details: Optional[Mapping[str, Any]] = None,
) -> CompanyFitDecisionResult:
    return CompanyFitDecisionResult(COMPANY_FIT_MISMATCH, reason, details=details)


def company_fit_unavailable(
    reason: Optional[str],
    *,
    details: Optional[Mapping[str, Any]] = None,
) -> CompanyFitDecisionResult:
    return CompanyFitDecisionResult(COMPANY_FIT_UNAVAILABLE, reason, details=details)
