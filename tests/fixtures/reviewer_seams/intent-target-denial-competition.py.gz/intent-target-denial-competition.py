"""Shared company scorer for the public baseline and miner bundles."""

from __future__ import annotations

from importlib import import_module
import hashlib
import json
import logging
import math
import os
from typing import Any, Callable, Mapping, MutableMapping, Sequence
from urllib.parse import urlsplit

from leadpoet_verifier.aggregation import per_icp_normalized_score
from leadpoet_verifier.identity.normalization import normalize_name
from pydantic import ValidationError
from qualification.competition_models import CompetitionCompany
from qualification.employee_buckets import (
    normalize_employee_count_bucket,
    normalize_observed_employee_count_bucket,
)
from qualification.scoring.arena_integrity import (
    bounded_criterion_evidence,
    canonical_company_identity,
    company_fit_verified,
    company_identity_alias_keys,
    fit_evidence_url_hints,
    verified_identity_receipt,
)


SCORING_ADAPTER_VERSION = "qualification-company-scorer:v1"
DEFAULT_COMPANY_GOAL = 5
MAX_COMPANY_GOAL = 5
FP_PENALTY_POINTS = 10.0
logger = logging.getLogger(__name__)

_PENALIZABLE_FAILURE_MARKERS = (
    "exclusion list",
    "required_attribute",
    "missing employee_count",
    "missing company_stage",
    "country mismatch",
    "missing country",
    "duplicate company",
    "data quality issue",
    "missing industry",
    "company verification failed",
)
_PENALIZABLE_NON_FIT_FAILURE_MARKERS = (
    "exclusion list",
    "duplicate company",
    "data quality issue",
)
_NEVER_PENALIZE_MARKERS = ("error", "timeout", "provider", "429")
_MODEL_CONTRACT_INCOMPATIBLE_FAILURE_CLASS = "model_contract_incompatible"
COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS = "company_verification_exhausted"
REQUIRED_ATTRIBUTE_QUOTE_ABSENT_FAILURE_CLASS = (
    "required_attribute_quote_absent"
)
INTENT_DETAILS_CITATION_UNAVAILABLE_FAILURE_CLASS = (
    "intent_details_citation_unavailable"
)
_NON_RETRYABLE_UNAVAILABLE_FAILURE_CLASSES = frozenset({
    "insufficient_fit_evidence",
    _MODEL_CONTRACT_INCOMPATIBLE_FAILURE_CLASS,
    COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS,
})
_SOURCE_LOCAL_FAILURE_REASON = "source_blocked"
_SOURCE_LOCAL_INTENT_STAGE_MARKERS = (
    "anti_bot_marker",
    "body_too_short",
    "html_empty_body",
    "js_shell",
    "non_textual",
    "exa_no_results",
    "exa_thin",
)
_SYSTEMIC_INTENT_STAGE_MARKERS = (
    "no_sd_key",
    "no_exa_key",
    "client_deadline",
    "transport_error",
    "exception",
    "exa_failed",
    "exa_http_error",
    "exa_transient_exhausted",
    "http_429",
    "http_5",
)
_EXA_TARGET_CRAWL_FAILURES = frozenset({
    ("CRAWL_LIVECRAWL_TIMEOUT", 504),
    ("CRAWL_UNKNOWN_ERROR", 500),
    ("SOURCE_NOT_AVAILABLE", 403),
})


class CompetitionScorerInputError(ValueError):
    """A company or ICP does not satisfy the public competition boundary."""


def _model_contract_incompatible_breakdown() -> dict[str, Any]:
    """Return a safe zero when one public company cannot enter the judge model."""

    return {
        "icp_fit": 0.0,
        "decision_maker": 0.0,
        "intent_signal_raw": 0.0,
        "time_decay_multiplier": 1.0,
        "intent_signal_final": 0.0,
        "cost_penalty": 0.0,
        "time_penalty": 0.0,
        "final_score": 0.0,
        "failure_reason": "company model contract incompatible",
        "intent_signals_detail": None,
        "verifier_gate_receipts": [
            {
                "gate": "company_fit",
                "decision": "unavailable",
                "reason": "company_model_contract_incompatible",
                "failure_class": _MODEL_CONTRACT_INCOMPATIBLE_FAILURE_CLASS,
            }
        ],
    }


def _text(value: Any) -> str:
    if isinstance(value, Mapping):
        return str(
            value.get("intent_signal")
            or value.get("signal")
            or value.get("text")
            or ""
        ).strip()
    return str(value or "").strip()


def _category(value: Any) -> str | None:
    if not isinstance(value, Mapping):
        return None
    text = str(
        value.get("intent_category")
        or value.get("category")
        or value.get("evidence_type")
        or ""
    ).strip().upper()
    return text or None


def _max_age_days(value: Any) -> int | None:
    if not isinstance(value, Mapping):
        return None
    raw = value.get("max_age_days")
    if raw is None:
        raw = value.get("intent_max_age_days")
    try:
        days = int(raw)
    except (TypeError, ValueError):
        return None
    return days if days > 0 else None


def employee_count_buckets_for_icp(icp: Mapping[str, Any]) -> list[str]:
    """Return the exact employee buckets declared by one ICP."""

    raw = icp.get("employee_count")
    values = (
        list(raw)
        if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes, bytearray))
        else str(raw or "").replace(";", "|").split("|")
    )
    buckets: list[str] = []
    for value in values:
        bucket = normalize_employee_count_bucket(value, default=None)
        if bucket and bucket not in buckets:
            buckets.append(bucket)
    if not buckets:
        raise CompetitionScorerInputError("ICP employee_count has no valid bucket")
    return buckets


def _company_goal(icp: Mapping[str, Any]) -> int:
    try:
        value = int(icp.get("max_companies", DEFAULT_COMPANY_GOAL))
    except (TypeError, ValueError):
        value = DEFAULT_COMPANY_GOAL
    return max(1, min(MAX_COMPANY_GOAL, value))


def _normalized_icp(icp: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(icp, Mapping):
        raise CompetitionScorerInputError("ICP must be an object")
    industry = str(icp.get("industry") or "").strip()
    icp_id = str(icp.get("icp_id") or "").strip()
    if not industry or not icp_id:
        raise CompetitionScorerInputError("ICP is missing icp_id or industry")

    signals: list[str] = []
    evidence_types: list[str | None] = []
    signal_max_age_days: list[int] = []
    primary_category = str(icp.get("intent_category") or "").strip().upper() or None
    primary_max_age_days = max(1, int(icp.get("intent_max_age_days") or 365))
    bonus_metadata = {
        _text(item): (_category(item), _max_age_days(item))
        for item in (icp.get("bonus_intents") or [])
        if isinstance(item, Mapping) and _text(item)
    }
    raw_signals = icp.get("intent_signals") or [icp.get("intent_signal")]
    if isinstance(raw_signals, (str, Mapping)):
        raw_signals = [raw_signals]
    for index, item in enumerate(raw_signals or []):
        signal = _text(item)
        if not signal or signal in signals:
            continue
        signals.append(signal)
        bonus_category, bonus_max_age_days = bonus_metadata.get(
            signal, (None, None)
        )
        evidence_types.append(
            _category(item)
            or bonus_category
            or (primary_category if index == 0 else None)
        )
        signal_max_age_days.append(
            _max_age_days(item)
            or bonus_max_age_days
            or primary_max_age_days
        )
    for item in icp.get("bonus_intents") or []:
        signal = _text(item)
        if signal and signal not in signals:
            signals.append(signal)
            evidence_types.append(_category(item))
            signal_max_age_days.append(
                _max_age_days(item) or primary_max_age_days
            )
    if not signals:
        raise CompetitionScorerInputError("ICP has no intent signal")

    buckets = employee_count_buckets_for_icp(icp)
    stage = icp.get("company_stage") or "Any"
    if isinstance(stage, Sequence) and not isinstance(stage, (str, bytes, bytearray)):
        stage = next((str(value).strip() for value in stage if str(value).strip()), "Any")
    country = str(icp.get("country") or "").strip()
    geography = str(icp.get("geography") or country or "United States").strip()
    required_attribute = str(icp.get("required_attribute") or "").strip()
    product_service = str(
        icp.get("product_service") or required_attribute or industry
    ).strip()
    prompt = str(icp.get("prompt") or "").strip()
    if not prompt:
        prompt = f"Find {industry} companies in {geography} with {signals[0]}"
    excluded = icp.get("excluded_companies") or []
    if not isinstance(excluded, list):
        excluded = []
    return {
        "icp_id": icp_id,
        "prompt": prompt,
        "industry": industry,
        "sub_industry": str(icp.get("sub_industry") or industry).strip(),
        "target_roles": [],
        "target_seniority": "",
        "employee_count": "|".join(buckets),
        "company_stage": str(stage).strip() or "Any",
        "geography": geography,
        "country": country or geography,
        "product_service": product_service,
        "required_attribute": required_attribute,
        "excluded_companies": [str(value) for value in excluded],
        "intent_signals": signals,
        "intent_signal_evidence_types": evidence_types,
        "intent_signal_max_age_days": signal_max_age_days,
        "intent_max_age_days": primary_max_age_days,
    }


def available_intent_score_cap(icp: Mapping[str, Any]) -> float:
    """Maximum raw intent score for this buyer's distinct requested criteria.

    Share the judge's ICP parser and cap table. Submitted evidence never sets
    the denominator, and repeated or bonus criteria have the same meaning in
    verification and score normalization.
    """

    from qualification.scoring.lead_scorer import COMPETITION_INTENT_CAP_BY_SIGNAL_COUNT

    count = len(_normalized_icp(icp)["intent_signals"])
    caps = COMPETITION_INTENT_CAP_BY_SIGNAL_COUNT
    return float(caps[min(count, max(caps))])


def _normalized_company(
    company: Mapping[str, Any], *, integrity_policy: bool = False,
    contacts_required: bool = False,
    company_quality: bool = False,
) -> dict[str, Any]:
    try:
        # Contact-bearing historical schemas are scored by an independent
        # contact gate. The company judge is contact-blind in every mode.
        company_input = dict(company)
        company_input.pop("contact", None)
        simplified_intent = "intent_details" in company_input
        if simplified_intent:
            from qualification.competition_models import CompetitionCompanyV5
            row = CompetitionCompanyV5.model_validate(company_input).model_dump(
                mode="json"
            )
            if company_quality:
                from qualification.company_quality import normalize_company_claim
                row, _errors = normalize_company_claim(row)
        elif company_quality:
            from qualification.competition_models import CompetitionCompanyV3
            from qualification.company_quality import normalize_company_claim
            row, _errors = normalize_company_claim(
                CompetitionCompanyV3.model_validate(company_input).model_dump(mode="json")
            )
        else:
            row = CompetitionCompany.model_validate(company_input).model_dump(mode="json")
    except Exception as exc:
        raise CompetitionScorerInputError(
            "company does not satisfy the competition output schema"
        ) from exc
    signals = [
        {
            "source": _evidence_source(
                signal["url"], company_website=row["company_website"]
            ),
            "description": signal["description"],
            "url": signal["url"],
            "date": signal["date"],
            "snippet": signal.get("snippet", ""),
            "matched_icp_signal": signal["matched_icp_signal"],
        }
        for signal in row["intent_signals"]
    ]
    stage_evidence = row.get("company_stage_evidence", [])
    stage_evidence_urls = [item["url"] for item in stage_evidence]
    if integrity_policy:
        signals = [signal for group in bounded_criterion_evidence(signals) for signal in group]
    return {
        "company_name": row["company_name"],
        "company_website": row["company_website"],
        "company_linkedin": row["company_linkedin"],
        "industry": row["industry"],
        "sub_industry": "",
        "employee_count": row["employee_count"],
        "company_stage": row["company_stage"],
        "country": row["country"],
        "state": "" if row["state"] is None else row["state"],
        "description": "" if simplified_intent else row["fit_summary"][:500],
        "fit_evidence_urls": (
            fit_evidence_url_hints(stage_evidence_urls)
            if simplified_intent
            else (
                fit_evidence_url_hints(row["fit_evidence_urls"])
                if integrity_policy
                else row["fit_evidence_urls"]
            )
        ),
        "company_stage_evidence": stage_evidence,
        **(
            {"intent_details": row["intent_details"]}
            if simplified_intent
            else {}
        ),
        "intent_signals": signals,
        "required_attribute": row.get("required_attribute"),
    }


def effective_competition_input(
    companies: Sequence[Mapping[str, Any]],
    icp: Mapping[str, Any],
    *,
    contacts_required: bool = False,
    contact_source_evidence: Mapping[str, Any] | None = None,
    provider_observations: Sequence[Mapping[str, Any]] | None = None,
    company_quality: bool = False,
) -> dict[str, Any]:
    """Project the same normalized first-N inputs consumed by the adapter.

    Company positions and order remain significant. Bucket-skipped companies
    have no judge input; output padding, unused prose and repeated/capped
    evidence cannot buy a fresh judgment.
    """
    buckets = employee_count_buckets_for_icp(icp)
    from gateway.qualification.models import CompanyOutput

    rows = []
    for company_index, company in enumerate(list(companies)[:_company_goal(icp)]):
        observed = company.get("employee_count")
        bucket = normalize_employee_count_bucket(observed, default=None) or normalize_observed_employee_count_bucket(observed, default=None)
        if bucket not in buckets and not company_quality:
            rows.append({"bucket_skipped": True})
            continue
        normalized = _normalized_company(
            company,
            integrity_policy=True,
            contacts_required=contacts_required,
            company_quality=company_quality,
        )
        if company_quality:
            from qualification.company_quality import normalize_company_claim
            _claim, errors = normalize_company_claim(company)
            if errors or bucket not in buckets:
                # No networked judgment, but retain every identity-affecting
                # input so a deterministic zero cannot bind to another firm.
                effective = dict(normalized)
                effective["company_quality_errors"] = list(errors)
                if bucket not in buckets:
                    effective["bucket_skipped"] = True
                if contacts_required:
                    effective.update(_effective_contact_input(company, contact_source_evidence))
                rows.append(effective)
                continue
        try:
            effective = CompanyOutput(**normalized).model_dump(mode="json")
        except ValidationError:
            # Preserve validation inputs for incompatible rows; none reach
            # the networked judge, and identity still affects their receipts.
            rows.append(normalized)
            continue
        if effective.get("intent_details") is None:
            # The optional internal bridge must not change historical cache
            # identities for v1-v4 outputs.
            effective.pop("intent_details", None)
        if not effective.get("company_stage_evidence"):
            # The additive V5 evidence packet must not change cache identities
            # for old checkpoints or V1-V4 rows.
            effective.pop("company_stage_evidence", None)
        # The binary Arena fit verifier independently resolves these facts.
        # Submitted prose and self-assessment do not prove a company match.
        for ignored in (("description",) if company_quality else ("state", "description")):
            effective.pop(ignored, None)
        attribute = effective.pop("required_attribute", None)
        if attribute and (attribute["evidence_url"] or attribute["evidence_quote"]):
            # Research and paragraph review consume these untrusted hints.
            effective["required_attribute"] = {
                field: attribute[field]
                for field in ("evidence_url", "evidence_quote")
            }
        if company_quality:
            from qualification.company_quality import is_united_states
            if not is_united_states(effective.get("country")):
                effective.pop("state", None)
        if contacts_required:
            effective.update(
                _effective_contact_input(company, contact_source_evidence)
            )
        observation = _effective_provider_observation(
            provider_observations, company_index
        )
        if observation is not None:
            effective["provider_observation"] = observation
        rows.append(effective)
    effective_icp = _normalized_icp(icp)
    if contacts_required:
        geography = icp.get("contact_geography")
        effective_icp.update({
            "target_roles": _normalized_string_list(icp.get("target_roles")),
            "target_seniority": str(icp.get("target_seniority") or "").strip(),
            "contact_geography": _normalized_contact_geography(geography),
        })
    return {"icp": effective_icp, "companies": rows}


def _normalized_string_list(value: Any) -> list[str]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        return []
    return list(dict.fromkeys(str(item).strip() for item in value if str(item).strip()))


def _normalized_contact_geography(value: Any) -> dict[str, list[str]]:
    if not isinstance(value, Mapping):
        return {"countries": [], "regions": [], "cities": []}
    from qualification.contact_models import normalize_country_code

    countries: list[str] = []
    for item in _normalized_string_list(value.get("countries")):
        try:
            normalized = normalize_country_code(item)
        except ValueError:
            normalized = item.casefold()
        if normalized not in countries:
            countries.append(normalized)
    return {
        "countries": countries,
        "regions": [item.casefold() for item in _normalized_string_list(value.get("regions"))],
        "cities": [item.casefold() for item in _normalized_string_list(value.get("cities"))],
    }


def _semantic_hash(value: Any) -> str:
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return "sha256:" + hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _without_cache_metadata(value: Any, depth: int = 0) -> Any:
    if depth > 8:
        return None
    if isinstance(value, Mapping):
        return {
            str(key): _without_cache_metadata(item, depth + 1)
            for key, item in value.items()
            if str(key) not in {"broker_call_id", "call_identity", "observed_at"}
        }
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_without_cache_metadata(item, depth + 1) for item in value]
    return value


def _effective_contact_input(
    company: Mapping[str, Any],
    source_evidence: Mapping[str, Any] | None,
) -> dict[str, Any]:
    from qualification.contact_models import validate_contact_claim

    raw_contact = company.get("contact")
    try:
        contact = validate_contact_claim(raw_contact)
    except (TypeError, ValueError):
        return {
            "contact_invalid_hash": _semantic_hash(
                _without_cache_metadata(raw_contact)
            )
        }
    source = (
        source_evidence.get(_contact_source_key(company))
        if isinstance(source_evidence, Mapping)
        else None
    )
    from qualification.scoring.contact_verification import (
        contact_source_semantics,
    )

    attribution = contact.get("email_source") or {}
    source_semantics = contact_source_semantics(
        source,
        broker_call_id=attribution.get("broker_call_id"),
        record_id=attribution.get("record_id"),
    )
    effective_source = {
        "provider": attribution.get("provider"),
        "tool": attribution.get("tool"),
    }
    if attribution.get("broker_call_id"):
        effective_source["broker_call_id"] = attribution["broker_call_id"]
    if attribution.get("record_id"):
        effective_source["record_id"] = attribution["record_id"]
    return {
        "contact": {
            "full_name": contact["full_name"],
            "role": contact["role"],
            "linkedin_url": contact["linkedin_url"],
            "location": contact["location"],
            "email": contact["email"],
            "email_source": effective_source,
        },
        "contact_source_evidence_hash": _semantic_hash(source_semantics),
    }


def _effective_provider_observation(
    observations: Sequence[Mapping[str, Any]] | None,
    company_index: int,
) -> dict[str, str] | None:
    from lab_arena.provider_observations import company_observation

    observation = company_observation(observations, company_index)
    if observation is None:
        return None
    return {
        "company_domain": observation["company_domain"],
        "source_url": observation["source_url"],
        "first_observed_date": observation["first_observed_date"],
    }


def _contact_source_key(company: Mapping[str, Any]) -> str:
    contact = company.get("contact")
    source = contact.get("email_source") if isinstance(contact, Mapping) else None
    if not isinstance(source, Mapping):
        return ""
    return str(source.get("broker_call_id") or source.get("record_id") or "")


def _evidence_source(url: str, *, company_website: str) -> str:
    """Infer the scorer's source class from the submitted public URL."""

    hostname = (urlsplit(str(url)).hostname or "").lower().removeprefix("www.")
    company_hostname = (
        (urlsplit(str(company_website)).hostname or "").lower().removeprefix("www.")
    )
    path = (urlsplit(str(url)).path or "").lower()
    if hostname == "linkedin.com" or hostname.endswith(".linkedin.com"):
        return "linkedin"
    if hostname == "github.com" or hostname.endswith(".github.com"):
        return "github"
    if any(marker in path for marker in ("/jobs", "/job/", "/careers")):
        return "job_board"
    if company_hostname and hostname == "careers." + company_hostname:
        return "job_board"
    if company_hostname and (
        hostname == company_hostname or hostname.endswith("." + company_hostname)
    ):
        return "company_website"
    return "news"


def _ensure_provider_environment() -> None:
    key = os.getenv("QUALIFICATION_OPENROUTER_API_KEY") or os.getenv(
        "OPENROUTER_API_KEY"
    )
    if not key:
        return
    os.environ.setdefault("QUALIFICATION_OPENROUTER_API_KEY", key)
    for module_name in ("qualification.scoring.verification_helpers",):
        module = import_module(module_name)
        if not getattr(module, "OPENROUTER_API_KEY", ""):
            setattr(module, "OPENROUTER_API_KEY", key)


def _not_evaluated_contact(company: Mapping[str, Any]) -> dict[str, Any]:
    from qualification.scoring.contact_verification import contact_identity_key

    reason = "company_not_qualified"
    return {
        "contact_qualified": False,
        "contact_identity_key": contact_identity_key(company.get("contact")),
        "email_status": "unknown",
        "contact_verification": {
            "decision": "not_evaluated",
            "reason": reason,
            "subchecks": {},
            "evidence_hashes": {},
            "evidence_timestamps": {},
        },
        "verifier_gate_receipts": [
            {"gate": "contact", "decision": "not_evaluated", "reason": reason}
        ],
    }


def _merge_contact_breakdown(
    breakdown: dict[str, Any], contact_result: Mapping[str, Any]
) -> None:
    existing_receipts = breakdown.get("verifier_gate_receipts")
    receipts = (
        list(existing_receipts)
        if isinstance(existing_receipts, Sequence)
        and not isinstance(existing_receipts, (str, bytes, bytearray))
        else []
    )
    contact_receipts = contact_result.get("verifier_gate_receipts")
    if isinstance(contact_receipts, Sequence) and not isinstance(
        contact_receipts, (str, bytes, bytearray)
    ):
        receipts.extend(contact_receipts)
    for key in (
        "contact_qualified",
        "contact_identity_key",
        "email_status",
        "contact_verification",
    ):
        breakdown[key] = contact_result[key]
    breakdown["verifier_gate_receipts"] = receipts


def _verified_company_for_contact(
    company: Mapping[str, Any], verified_receipt: Mapping[str, Any] | None
) -> dict[str, Any]:
    """Bind contact employment to the identity proven by the company gate."""
    if not isinstance(verified_receipt, Mapping):
        return dict(company)
    observed_domain = str(verified_receipt.get("observed_domain") or "").strip()
    observed_slug = str(
        verified_receipt.get("observed_linkedin_slug") or ""
    ).strip()
    return {
        "company_name": str(
            company.get("company_name") or ""
        ),
        "company_website": (
            f"https://{observed_domain}" if observed_domain else ""
        ),
        "company_linkedin": (
            f"https://www.linkedin.com/company/{observed_slug}/"
            if observed_slug
            else ""
        ),
        "contact": company.get("contact"),
    }


async def _classify_contact_role(
    actual_role: str,
    target_roles: list[str],
    target_seniority: str,
    duties: str = "",
) -> bool | dict[str, Any]:
    """Use the existing pinned role judge only for deterministic gray zones."""
    role_module = import_module("qualification.scoring.role_batch_check")
    key = (
        os.environ.get("OPENROUTER_KEY")
        or os.environ.get("OPENROUTER_API_KEY")
        or os.environ.get("QUALIFICATION_OPENROUTER_API_KEY")
    )
    if not key:
        raise RuntimeError("contact role judge key unavailable")
    expected_id = 1
    async with role_module.httpx.AsyncClient() as client:
        parsed = await role_module._judge_chunk(
            client,
            key,
            target_roles,
            [{"id": expected_id, "role": actual_role, "duties": duties}],
        )
        if (
            not isinstance(parsed, list)
            or len(parsed) != 1
            or not isinstance(parsed[0], Mapping)
            or type(parsed[0].get("id")) not in (int, str)
            or str(parsed[0]["id"]) != str(expected_id)
            or type(parsed[0].get("match")) is not bool
        ):
            raise RuntimeError("contact role judge response unavailable")
        if parsed[0]["match"] or not duties.strip():
            return parsed[0]["match"]
        finding = await role_module.review_role_evidence(
            client, key, actual_role=actual_role, target_roles=target_roles,
            target_seniority=target_seniority, duties=duties,
        )
        if finding is None:
            raise RuntimeError("contact role evidence review unavailable")
        return {
            "match": finding["status"] == "VERIFIED",
            "reason": finding["reason"],
            "evidence_review": finding,
        }


def raw_company_judgment(breakdown: Mapping[str, Any]) -> dict[str, Any]:
    """Remove list-dependent decisions before storing an intrinsic judgment."""
    return {
        key: value for key, value in breakdown.items()
        if key not in {"company_index", "company_qualified", "duplicate_company", "duplicate_of_index"}
    }


def bucket_skipped_judgment() -> dict[str, Any]:
    result = _model_contract_incompatible_breakdown()
    result.update(bucket_skipped=True, failure_reason="employee_bucket_skipped")
    return result


def company_quality_identity_verified(receipt: Any) -> bool:
    """A quality identity must contain independently observed usable handles."""
    from qualification.company_quality import canonical_company_linkedin
    from qualification.competition_models import public_http_url

    if not isinstance(receipt, Mapping):
        return False
    name = receipt.get("observed_name")
    domain = receipt.get("observed_domain")
    slug = receipt.get("observed_linkedin_slug")
    if any(not isinstance(value, str) or not value.strip() for value in (name, domain, slug)):
        return False
    try:
        observed = urlsplit("https://" + domain)
        if (observed.hostname != domain or observed.port is not None
            or observed.path or observed.query or observed.fragment
            or observed.username or observed.password):
            return False
        public_http_url("https://" + domain)
        linkedin = canonical_company_linkedin("https://linkedin.com/company/" + slug)
        if linkedin.rsplit("/", 1)[-1] != slug.casefold():
            return False
        identity = canonical_company_identity({}, verified_identity_receipt=receipt)
        return bool(identity.verified and identity.registrable_domain and identity.normalized_name and identity.verified_linkedin_slug)
    except (TypeError, ValueError):
        return False


def _verified_domain_name_hq_key(
    company: Mapping[str, Any], verified_domain: str
) -> tuple[str, ...] | None:
    """Identify an exact-name company alias without merging subsidiaries."""
    from qualification.company_quality import canonical_us_state
    from qualification.contact_models import normalize_country_code

    name = normalize_name(str(company.get("company_name") or ""))
    try:
        country = normalize_country_code(company.get("country"))
    except ValueError:
        country = normalize_name(str(company.get("country") or ""))
    state = canonical_us_state(company.get("state")) if country == "US" else ""
    domain = str(verified_domain or "").strip().casefold()
    if not name or not domain or not country:
        return None
    return ("verified_domain_name_hq", domain, name, country, state)


def _intent_details_gate_passed(breakdown: Mapping[str, Any]) -> bool:
    """Reject an explicit paragraph mismatch or unavailable decision."""
    receipts = breakdown.get("verifier_gate_receipts")
    if not isinstance(receipts, Sequence) or isinstance(receipts, (str, bytes)):
        return True
    return not any(
        isinstance(receipt, Mapping)
        and receipt.get("gate") == "intent_details"
        and receipt.get("decision") != "match" for receipt in receipts
    )


def legacy_prejudgment_duplicate(
    normalized_company: Mapping[str, Any], company_index: int,
    verified_identity_key_by_alias: Mapping[str, str], *,
    company: Mapping[str, Any], contacts_required: bool = False,
) -> dict[str, Any] | None:
    """The historical submitted-alias gate, before any provider call."""
    submitted_identity = canonical_company_identity(normalized_company)
    submitted_alias_keys = company_identity_alias_keys(submitted_identity)
    identity_key = next((verified_identity_key_by_alias[alias] for alias in submitted_alias_keys
                         if alias in verified_identity_key_by_alias), None)
    if identity_key is None:
        return None
    duplicate = _model_contract_incompatible_breakdown()
    duplicate.update({
        "failure_reason": "Duplicate company identity", "company_index": company_index,
        "company_identity_key": identity_key,
        "company_identity_alias_keys": list(submitted_alias_keys),
        "company_qualified": False, "duplicate_company": True,
    })
    if contacts_required:
        _merge_contact_breakdown(duplicate, _not_evaluated_contact(company))
    return duplicate


def legacy_postjudgment_context(
    breakdown: dict[str, Any], *, company: Mapping[str, Any],
    normalized_company: Mapping[str, Any], company_index: int,
    verified_identity_key_by_alias: dict[str, str],
) -> Mapping[str, Any]:
    """Apply the historical observed-alias and qualification decisions."""
    submitted_identity = canonical_company_identity(normalized_company)
    submitted_alias_keys = company_identity_alias_keys(submitted_identity)
    receipts = breakdown.get("verifier_gate_receipts")
    fit_verified = company_fit_verified(receipts)
    observed_receipt = verified_identity_receipt(receipts)
    contact_company = _verified_company_for_contact(
        company, observed_receipt
    )
    verified_identity = canonical_company_identity(
        normalized_company,
        verified_identity_receipt=observed_receipt,
    )
    current_identity_key = (
        verified_identity.key if observed_receipt else submitted_identity.key
    )
    identity_alias_keys = tuple(dict.fromkeys(
        (*submitted_alias_keys, *company_identity_alias_keys(verified_identity))
    ))
    prior_identity_key = next(
        (
            verified_identity_key_by_alias[alias]
            for alias in identity_alias_keys
            if alias in verified_identity_key_by_alias
        ),
        None,
    )
    duplicate_company = bool(
        fit_verified and prior_identity_key is not None
    )
    identity_key = prior_identity_key or current_identity_key
    if duplicate_company:
        for field, value in (
            ("icp_fit", 0.0),
            ("decision_maker", 0.0),
            ("intent_signal_raw", 0.0),
            ("time_decay_multiplier", 1.0),
            ("intent_signal_final", 0.0),
            ("cost_penalty", 0.0),
            ("time_penalty", 0.0),
            ("final_score", 0.0),
        ):
            breakdown[field] = value
        breakdown["failure_reason"] = "Duplicate company identity"
    primary_verified = has_verified_primary_intent(
        breakdown.get("intent_signals_detail") or []
    )
    paragraph_verified = _intent_details_gate_passed(breakdown)
    company_qualified = bool(
        fit_verified
        and primary_verified
        and paragraph_verified
        and float(breakdown.get("final_score") or 0) > 0
        and not duplicate_company
    )
    breakdown.update({
        "company_index": company_index,
        "company_identity_key": identity_key,
        "company_identity_alias_keys": list(identity_alias_keys),
        "company_qualified": company_qualified,
        "duplicate_company": duplicate_company,
    })
    if fit_verified and paragraph_verified and not duplicate_company:
        for alias in identity_alias_keys:
            verified_identity_key_by_alias[alias] = identity_key
    return contact_company


def apply_legacy_company_judgment_context(
    companies: Sequence[Mapping[str, Any]], raw_breakdowns: Sequence[Mapping[str, Any] | None],
    *, scored_indexes: Sequence[int] | None = None,
    resolve_raw: Callable[[int], Mapping[str, Any]] | None = None,
    consumed_indexes: set[int] | None = None,
) -> list[dict[str, Any]]:
    """Replay the historical gates; omitted intrinsic rows must be proved skips."""
    if len(companies) != len(raw_breakdowns):
        raise CompetitionScorerInputError("company judgments must cover every company")
    allowed = set(range(len(companies)) if scored_indexes is None else scored_indexes)
    seen: dict[str, str] = {}
    result = []
    for index, company in enumerate(companies):
        if index not in allowed:
            continue
        normalized = _normalized_company(company, integrity_policy=True)
        duplicate = legacy_prejudgment_duplicate(normalized, index, seen, company=company)
        if duplicate is not None:
            result.append(duplicate)
            continue
        from gateway.qualification.models import CompanyOutput
        try:
            CompanyOutput(**normalized)
        except ValidationError:
            incompatible = _model_contract_incompatible_breakdown()
            submitted_identity = canonical_company_identity(normalized)
            incompatible.update(company_index=index, company_identity_key=submitted_identity.key,
                company_identity_alias_keys=list(company_identity_alias_keys(submitted_identity)),
                company_qualified=False, duplicate_company=False)
            result.append(incompatible)
            continue
        raw = resolve_raw(index) if resolve_raw is not None else raw_breakdowns[index]
        if raw is None or raw.get("bucket_skipped"):
            raise CompetitionScorerInputError("company judgment is missing for an unskipped row")
        if consumed_indexes is not None:
            consumed_indexes.add(index)
        row = json.loads(json.dumps(raw, allow_nan=False))
        row.pop("company_judgment_policy", None)
        legacy_postjudgment_context(
            row, company=company, normalized_company=normalized, company_index=index,
            verified_identity_key_by_alias=seen,
        )
        result.append(row)
    return regroup_legacy_company_breakdowns(companies, result)


def regroup_legacy_company_breakdowns(companies, result):
    """Preserve the historical final regroup after company retry recovery."""
    from qualification.scoring.arena_integrity import mark_duplicate_companies
    original = mark_duplicate_companies(companies, limit=len(companies))
    seen = set()
    canonical_by_alias = {}
    verified_indexes = set()
    for breakdown in result:
        identity_key = breakdown.get("company_identity_key")
        aliases = breakdown.get("company_identity_alias_keys") or [identity_key]
        index = breakdown["company_index"]
        fit_verified = company_fit_verified(breakdown)
        duplicate_of = original[index].duplicate_of_index
        intersecting = seen.intersection(aliases)
        if duplicate_of in verified_indexes or (fit_verified and intersecting):
            breakdown.update({"final_score": 0.0,
                "company_qualified": False, "duplicate_company": True,
                "failure_reason": "duplicate_company_identity"})
            if intersecting:
                breakdown["company_identity_key"] = canonical_by_alias[sorted(intersecting)[0]]
        if fit_verified and not breakdown.get("duplicate_company") and identity_key:
            seen.update(aliases)
            for alias in aliases:
                canonical_by_alias.setdefault(alias, breakdown["company_identity_key"])
            verified_indexes.add(index)
    return result


def apply_company_judgment_context(
    companies: Sequence[Mapping[str, Any]],
    raw_breakdowns: Sequence[Mapping[str, Any]],
    *, contacts_required: bool = False, company_quality: bool = True,
    scored_indexes: Sequence[int] | None = None,
    resolve_raw: Callable[[int], Mapping[str, Any]] | None = None,
    consumed_indexes: set[int] | None = None,
) -> list[dict[str, Any]]:
    """Bind immutable single-company decisions to this list's verified identities.

    Inputs cover every first-N slot, including explicit bucket-skipped zeros.
    Only independently verified aliases can reserve another company's identity.
    """
    if not company_quality:
        return apply_legacy_company_judgment_context(
            companies, raw_breakdowns, scored_indexes=scored_indexes, resolve_raw=resolve_raw,
            consumed_indexes=consumed_indexes,
        )
    from qualification.company_quality import normalize_company_claim
    from qualification.scoring.company_fit_decision import company_quality_receipt_matches_claim

    if len(companies) != len(raw_breakdowns):
        raise CompetitionScorerInputError("company judgments must cover every company")
    result = []
    seen_identities: dict[tuple[str, ...], tuple[str, int]] = {}
    for index, (company, raw) in enumerate(zip(companies, raw_breakdowns)):
        if raw.get("bucket_skipped") is True:
            continue
        row = json.loads(json.dumps(raw, allow_nan=False))
        claim, errors = normalize_company_claim(company)
        receipt = verified_identity_receipt(row.get("verifier_gate_receipts"))
        identity = canonical_company_identity(claim, verified_identity_receipt=receipt)
        aliases = list(company_identity_alias_keys(identity)) or [identity.key]
        fit = (company_fit_verified(row) and company_quality_identity_verified(receipt)
               and company_quality_receipt_matches_claim(receipt, claim) and not errors)
        company_ready = bool(
            fit
            and has_verified_primary_intent(row.get("intent_signals_detail") or [])
            and _intent_details_gate_passed(row)
            and not scorer_breakdown_is_terminal_company_verification_failure(row)
        )
        qualified = bool(company_ready and float(row.get("final_score") or 0) > 0)
        if contacts_required:
            qualified = qualified and row.get("contact_qualified") is True
        identity_keys: list[tuple[str, ...]] = []
        if fit and identity.verified_linkedin_slug:
            identity_keys.append(("linkedin", identity.verified_linkedin_slug))
        if fit:
            domain_name_hq_key = _verified_domain_name_hq_key(
                claim, identity.registrable_domain
            )
            if domain_name_hq_key is not None:
                identity_keys.append(domain_name_hq_key)
        prior = None
        if company_ready:
            prior = next(
                (seen_identities[key] for key in identity_keys if key in seen_identities),
                None,
            )
        duplicate = prior is not None
        qualified = bool(qualified and not duplicate)
        row.update(
            company_index=index,
            company_identity_key=prior[0] if prior else identity.key,
            company_identity_alias_keys=aliases,
            company_qualified=bool(qualified),
            duplicate_company=duplicate,
        )
        if duplicate:
            row["duplicate_of_index"] = prior[1]
            row["failure_reason"] = "duplicate_company_identity"
            for field in ("icp_fit", "decision_maker", "intent_signal_raw", "intent_signal_final", "cost_penalty", "time_penalty"):
                row[field] = 0.0
        if not qualified:
            row["final_score"] = 0.0
        if contacts_required and (not company_ready or duplicate):
            row["verifier_gate_receipts"] = [
                item for item in row.get("verifier_gate_receipts") or []
                if not isinstance(item, Mapping) or item.get("gate") != "contact"
            ]
            _merge_contact_breakdown(row, _not_evaluated_contact(company))
        if qualified:
            for key in identity_keys:
                seen_identities[key] = (identity.key, index)
        result.append(row)
    return result


class CompetitionCompanyScorer:
    """Use the production company judge for baseline and miner outputs."""

    def __init__(
        self,
        integrity_policy: bool = False,
        *,
        contacts_required: bool = False,
        contact_source_evidence: Mapping[str, Any] | None = None,
        provider_observations: Sequence[Mapping[str, Any]] | None = None,
        company_quality: bool = False,
        evidence_investigator: bool = False,
        scorer_policy: Mapping[str, Any] | None = None,
    ) -> None:
        self.company_quality = bool(company_quality)
        self.contacts_required = bool(contacts_required)
        self.evidence_investigator = bool(evidence_investigator)
        self.integrity_policy = bool(integrity_policy or self.contacts_required or self.company_quality)
        self.contact_source_evidence = (
            dict(contact_source_evidence)
            if isinstance(contact_source_evidence, Mapping)
            else {}
        )
        self.provider_observations = (
            [dict(item) for item in provider_observations]
            if isinstance(provider_observations, Sequence)
            and not isinstance(provider_observations, (str, bytes, bytearray))
            else []
        )
        self.scorer_policy = json.loads(json.dumps(
            dict(scorer_policy or {}),
            sort_keys=True,
            separators=(",", ":"),
        ))

    def _retry_source_scope_key(self, company: Any, icp: Any) -> str:
        """Bind private retry evidence to every frozen scoring input."""

        from qualification.scoring.evaluation_clock import evaluation_date

        return _semantic_hash({
            "schema_version": "leadpoet.lab_arena.retry_source_evidence_scope.v1",
            "company": company.model_dump(mode="json"),
            "icp": icp.model_dump(mode="json"),
            "evaluation_date": evaluation_date().isoformat(),
            "scorer_policy": self.scorer_policy,
            "integrity_policy": self.integrity_policy,
            "contacts_required": self.contacts_required,
            "company_quality": self.company_quality,
            "evidence_investigator": self.evidence_investigator,
        })

    async def __call__(
        self,
        companies: Sequence[Mapping[str, Any]],
        icp: Mapping[str, Any],
        is_reference_model: bool,
    ) -> list[float]:
        rows = await self.score_with_breakdowns(companies, icp, is_reference_model)
        return [float(row.get("final_score") or 0.0) for row in rows]

    async def score_with_breakdowns(
        self,
        companies: Sequence[Mapping[str, Any]],
        icp: Mapping[str, Any],
        is_reference_model: bool,
        *,
        retry_evidence_scope: MutableMapping[str, Any] | None = None,
        original_company_indexes: Sequence[int] | None = None,
        prior_terminal_breakdowns: Sequence[Mapping[str, Any]] | None = None,
        on_company_breakdown: Callable[[dict[str, Any]], None] | None = None,
    ) -> list[dict[str, Any]]:
        indexes = (
            list(range(len(companies))) if original_company_indexes is None
            else list(original_company_indexes)
        )
        if len(indexes) != len(companies) or any(
            type(index) is not int or index < 0 for index in indexes
        ):
            raise CompetitionScorerInputError("original company index mapping is invalid")
        if not self.company_quality:
            return await self._score_with_breakdowns(
                companies,
                icp,
                is_reference_model,
                retry_evidence_scope=retry_evidence_scope,
                original_company_indexes=indexes,
                **({"prior_terminal_breakdowns": prior_terminal_breakdowns,
                    "on_company_breakdown": on_company_breakdown}
                   if on_company_breakdown is not None else {}),
            )
        sliced = list(companies)[:_company_goal(icp)]
        raw = []
        for index, company in enumerate(sliced):
            rows = await self._score_with_breakdowns(
                [company],
                icp,
                is_reference_model,
                retry_evidence_scope=retry_evidence_scope,
                original_company_indexes=[indexes[index]],
            )
            raw.append(raw_company_judgment(rows[0]) if rows else bucket_skipped_judgment())
        return apply_company_judgment_context(sliced, raw, contacts_required=self.contacts_required)

    async def _score_with_breakdowns(
        self,
        companies: Sequence[Mapping[str, Any]],
        icp: Mapping[str, Any],
        is_reference_model: bool,
        *,
        retry_evidence_scope: MutableMapping[str, Any] | None = None,
        original_company_indexes: Sequence[int],
        prior_terminal_breakdowns: Sequence[Mapping[str, Any]] | None = None,
        on_company_breakdown: Callable[[dict[str, Any]], None] | None = None,
    ) -> list[dict[str, Any]]:
        models = import_module("gateway.qualification.models")
        scorer_module = import_module("qualification.scoring.lead_scorer")
        _ensure_provider_environment()
        icp_data = _normalized_icp(icp)
        allowed_buckets = employee_count_buckets_for_icp(icp)
        icp_model = getattr(models, "ICPPrompt")(**icp_data)
        company_type = getattr(models, "CompanyOutput")
        score_company = scorer_module.score_company_competition_intent

        seen_companies: set[str] = set()
        verified_identity_key_by_alias: dict[str, str] = {}
        breakdowns: list[dict[str, Any]] = []
        prior_by_index = {row["company_index"]: dict(row)
                          for row in (prior_terminal_breakdowns or [])}

        def retain_row(row):
            breakdowns.append(row)
            if on_company_breakdown is not None:
                on_company_breakdown(dict(row))

        for company_index, company in enumerate(
            list(companies)[: _company_goal(icp)]
        ):
            observed = (company or {}).get("employee_count")
            bucket = normalize_employee_count_bucket(
                observed, default=None
            ) or normalize_observed_employee_count_bucket(observed, default=None)
            if not bucket or bucket not in allowed_buckets:
                continue
            if company_index in prior_by_index:
                # Walk the original group in order. A retained negative can
                # still reserve its independently verified identity and fit.
                prior = dict(prior_by_index[company_index])
                aliases = prior.get("company_identity_alias_keys") or [prior["company_identity_key"]]
                if (company_fit_verified(prior) and _intent_details_gate_passed(prior)
                    and not prior.get("duplicate_company")):
                    ancestor = next((verified_identity_key_by_alias[alias] for alias in aliases
                                     if alias in verified_identity_key_by_alias), None)
                    if ancestor is not None:
                        # An earlier unresolved slot has now verified the same
                        # identity. Reapply the ordinary duplicate projection.
                        for field, value in (("icp_fit", 0.0), ("decision_maker", 0.0),
                            ("intent_signal_raw", 0.0), ("time_decay_multiplier", 1.0),
                            ("intent_signal_final", 0.0), ("cost_penalty", 0.0),
                            ("time_penalty", 0.0), ("final_score", 0.0)):
                            prior[field] = value
                        prior.update(company_identity_key=ancestor, company_qualified=False,
                                     duplicate_company=True, failure_reason="Duplicate company identity")
                        if self.contacts_required:
                            _merge_contact_breakdown(prior, _not_evaluated_contact(company))
                    else:
                        for alias in aliases:
                            verified_identity_key_by_alias[alias] = prior["company_identity_key"]
                retain_row(prior)
                continue
            if self.company_quality:
                from qualification.company_quality import normalize_company_claim
                company, errors = normalize_company_claim(company)
                if errors:
                    invalid = _model_contract_incompatible_breakdown()
                    invalid["failure_reason"] = ";".join(errors)
                    if self.contacts_required:
                        _merge_contact_breakdown(invalid, _not_evaluated_contact(company))
                    retain_row(invalid)
                    continue
            normalized_company = _normalized_company(
                company,
                integrity_policy=self.integrity_policy,
                contacts_required=self.contacts_required,
                company_quality=self.company_quality,
            )
            contact_company = dict(company)
            submitted_identity = canonical_company_identity(normalized_company)
            submitted_alias_keys = company_identity_alias_keys(submitted_identity)
            if self.integrity_policy:
                duplicate = legacy_prejudgment_duplicate(
                    normalized_company, company_index, verified_identity_key_by_alias,
                    company=company, contacts_required=self.contacts_required,
                )
                if duplicate is not None:
                    retain_row(duplicate)
                    continue
            try:
                company_model = company_type(**normalized_company)
            except ValidationError:
                incompatible = _model_contract_incompatible_breakdown()
                if self.integrity_policy:
                    incompatible.update({
                        "company_index": company_index,
                        "company_identity_key": submitted_identity.key,
                        "company_identity_alias_keys": list(submitted_alias_keys),
                        "company_qualified": False,
                        "duplicate_company": False,
                    })
                if self.contacts_required:
                    _merge_contact_breakdown(
                        incompatible, _not_evaluated_contact(company)
                    )
                retain_row(incompatible)
                continue
            required_attribute_retry_source_cache = None
            matched_company_retry_source_cache = None
            verified_company_fit_retry_cache = None
            intent_terminal_retry_cache = None
            retry_evidence_context_key = ""
            if isinstance(retry_evidence_scope, MutableMapping):
                source_scope_key = self._retry_source_scope_key(
                    company_model,
                    icp_model,
                )
                retry_evidence_context_key = source_scope_key
                scoped_cache = retry_evidence_scope.setdefault(
                    source_scope_key,
                    {},
                )
                if isinstance(scoped_cache, MutableMapping):
                    required_attribute_retry_source_cache = scoped_cache
                matched_source_cache = retry_evidence_scope.setdefault(
                    f"matched-company-source-v1:{source_scope_key}",
                    {},
                )
                if isinstance(matched_source_cache, MutableMapping):
                    matched_company_retry_source_cache = matched_source_cache
                verified_fit_cache = retry_evidence_scope.setdefault(
                    f"verified-company-fit-v1:{source_scope_key}", {},
                )
                if isinstance(verified_fit_cache, MutableMapping):
                    verified_company_fit_retry_cache = verified_fit_cache
                intent_cache = retry_evidence_scope.setdefault(
                    f"intent-terminal-v1:{source_scope_key}",
                    {},
                )
                if isinstance(intent_cache, MutableMapping):
                    intent_terminal_retry_cache = intent_cache
            provider_observation = _effective_provider_observation(
                # Retries and quality splits can change the local list index.
                # Keep its output index local, but select the original witness.
                self.provider_observations, original_company_indexes[company_index]
            )
            result = await score_company(
                company=company_model,
                icp=icp_model,
                run_cost_usd=0.0,
                run_time_seconds=0.0,
                seen_companies=(seen_companies if not self.integrity_policy else set()),
                is_reference_model=bool(is_reference_model),
                integrity_policy=self.integrity_policy,
                evidence_investigator=self.evidence_investigator,
                required_attribute_retry_source_cache=(
                    required_attribute_retry_source_cache
                ),
                matched_company_retry_source_cache=(
                    matched_company_retry_source_cache
                ),
                verified_company_fit_retry_cache=verified_company_fit_retry_cache,
                intent_terminal_retry_cache=intent_terminal_retry_cache,
                retry_evidence_context_key=retry_evidence_context_key,
                **(
                    {"provider_observation": provider_observation}
                    if provider_observation is not None else {}
                ),
                **({"company_quality": True} if self.company_quality else {}),
            )
            breakdown = (
                result.model_dump(mode="json")
                if hasattr(result, "model_dump")
                else dict(result)
            )
            if self.integrity_policy:
                contact_company = legacy_postjudgment_context(
                    breakdown, company=company, normalized_company=normalized_company,
                    company_index=company_index,
                    verified_identity_key_by_alias=verified_identity_key_by_alias,
                )
            if self.contacts_required:
                if breakdown.get("company_qualified") is True:
                    from qualification.scoring.contact_verification import (
                        verify_contact,
                    )

                    contact_result = await verify_contact(
                        contact_company,
                        icp,
                        source_evidence=self.contact_source_evidence.get(
                            _contact_source_key(company)
                        ),
                        classify_role=_classify_contact_role,
                    )
                else:
                    contact_result = _not_evaluated_contact(company)
                _merge_contact_breakdown(breakdown, contact_result)
                if (
                    breakdown.get("company_qualified") is True
                    and contact_result.get("contact_qualified") is not True
                    and not breakdown.get("failure_reason")
                ):
                    breakdown["failure_reason"] = (
                        contact_result.get("contact_verification", {}).get("reason")
                        or "contact_not_qualified"
                    )
                breakdown["company_qualified"] = bool(
                    breakdown.get("company_qualified")
                    and contact_result.get("contact_qualified") is True
                )
                if not breakdown["company_qualified"]:
                    breakdown["final_score"] = 0.0
            retain_row(breakdown)
        return breakdowns


def _confirmed_exa_target_crawl_failure(value: Any) -> bool:
    """Validate the bounded two-attempt receipt retained by the verifier."""

    if not isinstance(value, Mapping) or set(value) != {
        "id_matches_requested_url", "confirmed_attempts", "observations"
    }:
        return False
    observations = value.get("observations")
    return bool(
        value.get("id_matches_requested_url") is True
        and type(value.get("confirmed_attempts")) is int
        and value.get("confirmed_attempts") == 2
        and isinstance(observations, list)
        and len(observations) == 2
        and all(
            isinstance(observation, Mapping)
            and set(observation) == {"error_tag", "error_http_status"}
            and isinstance(observation.get("error_tag"), str)
            and type(observation.get("error_http_status")) is int
            and (
                observation.get("error_tag"),
                observation.get("error_http_status"),
            ) in _EXA_TARGET_CRAWL_FAILURES
            for observation in observations
        )
    )


def _confirmed_exa_target_absence(value: Any) -> bool:
    """Validate the projected two-attempt exact-target not-found receipt."""

    return bool(
        isinstance(value, Mapping)
        and set(value) == {
            "id_matches_requested_url",
            "status",
            "error_tag",
            "error_http_status",
            "confirmed_attempts",
        }
        and value.get("id_matches_requested_url") is True
        and value.get("status") == "error"
        and value.get("error_tag") == "CRAWL_NOT_FOUND"
        and type(value.get("error_http_status")) is int
        and value.get("error_http_status") == 404
        and type(value.get("confirmed_attempts")) is int
        and value.get("confirmed_attempts") == 2
    )


def _intent_attempts_have_exact_target_crawl_exhaustion(attempts: Any) -> bool:
    """Accept only known Exa successes plus exact repeated target failures."""

    if not isinstance(attempts, Sequence) or isinstance(attempts, (str, bytes)):
        return False
    rows = list(attempts)
    if not rows or any(not isinstance(row, Mapping) for row in rows):
        return False
    proven_failures = 0
    for row in rows:
        if not isinstance(row.get("url"), str) or not row.get("url"):
            return False
        if row.get("source") == "exa_fallback" and row.get("stage") == "exa_scraped":
            continue
        exact_crawl_failure = bool(
            row.get("exa_stage") == "exa_no_results"
            and _confirmed_exa_target_crawl_failure(
                row.get("exa_target_crawl_failure")
            )
        )
        exact_target_absence = bool(
            row.get("exa_stage") == "exa_target_not_found"
            and _confirmed_exa_target_absence(row.get("exa_target_absence"))
        )
        if not (
            row.get("source") == "none"
            and row.get("sd_stage") == "all_tiers_exhausted:http_502"
            and (exact_crawl_failure or exact_target_absence)
        ):
            return False
        proven_failures += 1
    return proven_failures > 0


def _intent_detail_has_source_local_failure(detail: Any) -> bool:
    """Recognize bounded source-content exhaustion without reading prose."""

    if not isinstance(detail, Mapping):
        return False
    verdict = detail.get("judge_verdict")
    if not isinstance(verdict, Mapping):
        return False
    if verdict.get("failure_reason_code") == _SOURCE_LOCAL_FAILURE_REASON:
        return True
    if (
        verdict.get("decision") != "rejected_verifier_error"
        or verdict.get("pipeline_decision") != "unavailable"
        or verdict.get("rejection_reason") != "evidence_fetch_failed"
        or verdict.get("error_class")
    ):
        return False
    trace = verdict.get("verification_trace")
    attempts = trace.get("provider_attempts") if isinstance(trace, Mapping) else None
    if not isinstance(attempts, Sequence) or isinstance(attempts, (str, bytes)) or not attempts:
        return False
    if _intent_attempts_have_exact_target_crawl_exhaustion(attempts):
        return True
    for attempt in attempts:
        if not isinstance(attempt, Mapping):
            return False
        stages = [
            str(value).casefold()
            for key, value in attempt.items()
            if (str(key) == "source" or str(key).endswith("stage"))
            and isinstance(value, str)
        ]
        if any(
            marker in stage
            for stage in stages
            for marker in _SYSTEMIC_INTENT_STAGE_MARKERS
        ):
            return False
        if (
            attempt.get("source") == "none"
            and attempt.get("sd_stage") in {"genuine_404", "genuine_410"}
            and attempt.get("exa_stage") == "exa_target_not_found"
            and _confirmed_exa_target_absence(attempt.get("exa_target_absence"))
        ):
            # A corroborating URL can be absent while another source only
            # exhausted content. Keep that mixed result source-local without
            # claiming that the original URL itself was proved absent.
            continue
        if (
            attempt.get("source") == "scrapingdog_ashby_api_fallback"
            and attempt.get("stage") == "ashby_posting_not_listed"
            and set(attempt) == {"url", "source", "stage"}
            and isinstance(attempt.get("url"), str)
            and bool(attempt["url"])
        ):
            # Two valid API listings omitted the exact posting. This is only
            # source-local unavailability; later fetch failures still govern.
            continue
        if not any(
            marker in stage
            for stage in stages
            for marker in _SOURCE_LOCAL_INTENT_STAGE_MARKERS
        ):
            return False
    return True


def scorer_breakdown_has_company_local_verification_failure(
    breakdown: Mapping[str, Any],
) -> bool:
    """Return true only for a typed failure tied to one company's sources."""

    if not isinstance(breakdown, Mapping):
        return False
    receipts = breakdown.get("verifier_gate_receipts")
    terminal_gates: set[str] = set()
    source_local = False
    if isinstance(receipts, Sequence) and not isinstance(receipts, (str, bytes)):
        for receipt in receipts:
            if not isinstance(receipt, Mapping):
                continue
            if receipt.get("decision") != "unavailable":
                continue
            failure_class = str(receipt.get("failure_class") or "")
            if failure_class == COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS:
                terminal_gates.add(str(receipt.get("gate") or ""))
                source_local = True
                continue
            if (
                receipt.get("gate") == "company_fit"
                and failure_class
                == REQUIRED_ATTRIBUTE_QUOTE_ABSENT_FAILURE_CLASS
            ):
                source_local = True
                continue
            if (
                receipt.get("gate") == "company_fit"
                and receipt.get("failure_reason_code")
                == _SOURCE_LOCAL_FAILURE_REASON
            ):
                source_local = True
                continue
            if (
                receipt.get("gate") == "intent_details"
                and failure_class
                == INTENT_DETAILS_CITATION_UNAVAILABLE_FAILURE_CLASS
                and receipt.get("failure_reason_code") == "malformed_response"
            ):
                source_local = True
                continue
            if failure_class in _NON_RETRYABLE_UNAVAILABLE_FAILURE_CLASSES:
                continue
            # An unavailable gate without explicit source-local evidence can
            # be a shared provider or contract failure. Keep it systemic.
            return False
    details = breakdown.get("intent_signals_detail")
    if isinstance(details, Sequence) and not isinstance(details, (str, bytes)):
        for detail in details:
            if not _intent_detail_is_unavailable(detail):
                continue
            verdict = detail.get("judge_verdict")
            if not isinstance(verdict, Mapping):
                return False
            if (
                verdict.get("error_class")
                or verdict.get("failure_reason_code")
                in {"malformed_response", "provider_error", "unexpected_verifier_error"}
            ):
                return False
            trace = verdict.get("verification_trace")
            attempts = (
                trace.get("provider_attempts")
                if isinstance(trace, Mapping)
                else None
            )
            exact_target_crawl_exhaustion = (
                verdict.get("decision") == "rejected_verifier_error"
                and verdict.get("pipeline_decision") == "unavailable"
                and verdict.get("rejection_reason") == "evidence_fetch_failed"
                and _intent_attempts_have_exact_target_crawl_exhaustion(attempts)
            )
            if isinstance(attempts, Sequence) and not isinstance(attempts, (str, bytes)):
                stages = [
                    str(value).casefold()
                    for attempt in attempts
                    if isinstance(attempt, Mapping)
                    for key, value in attempt.items()
                    if (str(key) == "source" or str(key).endswith("stage"))
                    and isinstance(value, str)
                ]
                if not exact_target_crawl_exhaustion and any(
                    marker in stage
                    for stage in stages
                    for marker in _SYSTEMIC_INTENT_STAGE_MARKERS
                ):
                    return False
            if exact_target_crawl_exhaustion:
                source_local = True
                continue
            if _intent_detail_has_source_local_failure(detail):
                source_local = True
                continue
            # Public redaction removes source traces. The terminal intent gate
            # is the retained typed decision for that exact unavailable detail.
            if "intent_verification" not in terminal_gates:
                return False
    return source_local


def scorer_breakdown_is_terminal_company_verification_failure(
    breakdown: Mapping[str, Any],
) -> bool:
    receipts = breakdown.get("verifier_gate_receipts")
    return bool(
        isinstance(receipts, Sequence)
        and not isinstance(receipts, (str, bytes))
        and any(
            isinstance(receipt, Mapping)
            and receipt.get("failure_class")
            == COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS
            for receipt in receipts
        )
    )


def terminal_company_verification_breakdown(
    breakdown: Mapping[str, Any],
) -> dict[str, Any]:
    """Convert one exhausted source-local verification into a stable zero."""

    if not scorer_breakdown_has_company_local_verification_failure(breakdown):
        raise CompetitionScorerInputError(
            "company verification failure is not source-local"
        )
    details = breakdown.get("intent_signals_detail")
    has_local_intent = bool(
        isinstance(details, Sequence)
        and not isinstance(details, (str, bytes))
        and any(
            _intent_detail_is_unavailable(detail)
            and _intent_detail_has_source_local_failure(detail)
            for detail in details
        )
    )
    result = json.loads(json.dumps(dict(breakdown), allow_nan=False))
    receipts = result.get("verifier_gate_receipts")
    if not isinstance(receipts, list):
        receipts = []
    marked = False
    for receipt in receipts:
        if not isinstance(receipt, dict):
            continue
        if receipt.get("failure_class") == COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS:
            marked = True
        elif (
            receipt.get("gate") == "company_fit"
            and receipt.get("decision") == "unavailable"
            and (
                receipt.get("failure_reason_code")
                == _SOURCE_LOCAL_FAILURE_REASON
                or receipt.get("failure_class")
                == REQUIRED_ATTRIBUTE_QUOTE_ABSENT_FAILURE_CLASS
            )
        ):
            receipt["failure_class"] = COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS
            marked = True
        elif (
            receipt.get("gate") == "intent_details"
            and receipt.get("decision") == "unavailable"
            and receipt.get("failure_class")
            == INTENT_DETAILS_CITATION_UNAVAILABLE_FAILURE_CLASS
            and receipt.get("failure_reason_code") == "malformed_response"
        ):
            receipt["failure_class"] = COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS
            marked = True
    has_terminal_intent = any(
        isinstance(receipt, Mapping)
        and receipt.get("gate") == "intent_verification"
        and receipt.get("failure_class")
        == COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS
        for receipt in receipts
    )
    if not marked or (has_local_intent and not has_terminal_intent):
        receipts.append({
            "gate": "intent_verification",
            "decision": "unavailable",
            "failure_class": COMPANY_VERIFICATION_EXHAUSTED_FAILURE_CLASS,
        })
    result["verifier_gate_receipts"] = receipts
    for field, value in (
        ("icp_fit", 0.0),
        ("decision_maker", 0.0),
        ("intent_signal_raw", 0.0),
        ("time_decay_multiplier", 1.0),
        ("intent_signal_final", 0.0),
        ("cost_penalty", 0.0),
        ("time_penalty", 0.0),
        ("final_score", 0.0),
    ):
        result[field] = value
    if "company_qualified" in result:
        result["company_qualified"] = False
    return result


def scorer_breakdown_has_retryable_infrastructure_failure(
    breakdown: Mapping[str, Any], *, integrity_policy: bool = False
) -> bool:
    if not isinstance(breakdown, Mapping):
        return False
    if (
        scorer_breakdown_is_terminal_company_verification_failure(breakdown)
        and scorer_breakdown_has_company_local_verification_failure(breakdown)
    ):
        return False
    receipts = breakdown.get("verifier_gate_receipts")
    if isinstance(receipts, Sequence) and not isinstance(receipts, (str, bytes)):
        for receipt in receipts:
            if (
                isinstance(receipt, Mapping)
                and str(receipt.get("decision") or "") == "unavailable"
                and str(receipt.get("failure_class") or "")
                not in _NON_RETRYABLE_UNAVAILABLE_FAILURE_CLASSES
            ):
                return True
    details = breakdown.get("intent_signals_detail")
    if isinstance(details, Sequence) and not isinstance(details, (str, bytes)):
        if intent_unavailability_requires_retry(
            details, integrity_policy=integrity_policy
        ):
            return True
    reason = str(breakdown.get("failure_reason") or "").strip().lower()
    return bool(reason) and any(
        marker in reason
        for marker in (
            "intent verification unavailable:",
            "llm scoring error:",
            "company verification error:",
            "company verification failed: website unreachable:",
            "company verification failed: website fetch error:",
            "company verification unavailable:",
            "company fit pre-check unavailable:",
            "company web re-verification unavailable:",
            "providerclientv2error",
            "runner external request must use https",
            "provider error",
            "provider timeout",
            "http 429",
            "no_openrouter_key",
        )
    )


def _intent_detail_is_unavailable(detail: Any) -> bool:
    if not isinstance(detail, Mapping):
        return False
    verdict = detail.get("judge_verdict")
    return isinstance(verdict, Mapping) and (
        str(verdict.get("decision") or "") == "rejected_verifier_error"
        or bool(verdict.get("error_class"))
        or str(verdict.get("pipeline_decision") or "") == "unavailable"
    )


def has_verified_primary_intent(details: Sequence[Any]) -> bool:
    """Return whether structured details contain a usable primary score."""

    rejected_statuses = {"contradicted", "unable_to_verify", "wrong_entity"}
    for detail in details:
        if not isinstance(detail, Mapping):
            continue
        index = detail.get("matched_icp_signal")
        score = detail.get("after_decay")
        if (
            isinstance(index, bool)
            or not isinstance(index, int)
            or index != 0
            or isinstance(score, bool)
            or not isinstance(score, (int, float))
            or not math.isfinite(float(score))
            or float(score) <= 0.0
        ):
            continue
        verdict = detail.get("judge_verdict")
        if (
            not isinstance(verdict, Mapping)
            or str(verdict.get("decision") or "") != "verified"
            or bool(verdict.get("error_class"))
            or str(verdict.get("pipeline_decision") or "")
            in {"reject", "unavailable"}
        ):
            continue
        trace = verdict.get("verification_trace")
        intent_verdict = (
            trace.get("intent_verdict") if isinstance(trace, Mapping) else None
        )
        evaluations = (
            intent_verdict.get("signal_evaluations")
            if isinstance(intent_verdict, Mapping)
            else None
        )
        if isinstance(evaluations, Sequence) and not isinstance(
            evaluations, (str, bytes)
        ) and any(
            isinstance(evaluation, Mapping)
            and str(evaluation.get("signal_status") or "") in rejected_statuses
            for evaluation in evaluations
        ):
            continue
        return True
    return False


def intent_unavailability_requires_retry(
    details: Sequence[Any], *, integrity_policy: bool = False
) -> bool:
    """Retry any unavailable integrity signal; legacy needs no verified primary."""

    unavailable = any(_intent_detail_is_unavailable(detail) for detail in details)
    return unavailable and (
        integrity_policy or not has_verified_primary_intent(details)
    )


def _structured_fit_mismatch(breakdown: Mapping[str, Any]) -> bool:
    receipts = breakdown.get("verifier_gate_receipts")
    return isinstance(receipts, Sequence) and not isinstance(
        receipts, (str, bytes)
    ) and any(
        isinstance(receipt, Mapping)
        and str(receipt.get("gate") or "") == "company_fit"
        and str(receipt.get("decision") or "") == "mismatch"
        for receipt in receipts
    )


def _has_structured_fit_verdict(breakdown: Mapping[str, Any]) -> bool:
    receipts = breakdown.get("verifier_gate_receipts")
    return isinstance(receipts, Sequence) and not isinstance(
        receipts, (str, bytes)
    ) and any(
        isinstance(receipt, Mapping)
        and receipt.get("gate") == "company_fit"
        and receipt.get("decision") in {"match", "mismatch", "unavailable"}
        for receipt in receipts
    )


def count_penalizable_false_positives(
    breakdowns: Sequence[Mapping[str, Any]], *, icp_has_intent_signals: bool,
    fit_receipt_authoritative: bool = False,
) -> tuple[int, int]:
    gate_failures = 0
    unverified_primary = 0
    for row in breakdowns:
        if (
            not isinstance(row, Mapping)
            or (
                scorer_breakdown_is_terminal_company_verification_failure(row)
                and scorer_breakdown_has_company_local_verification_failure(row)
            )
            or scorer_breakdown_has_retryable_infrastructure_failure(row)
        ):
            continue
        if _structured_fit_mismatch(row):
            gate_failures += 1
            continue
        reason = str(row.get("failure_reason") or "").strip().lower()
        if reason:
            markers = (
                _PENALIZABLE_NON_FIT_FAILURE_MARKERS
                if fit_receipt_authoritative and _has_structured_fit_verdict(row)
                else _PENALIZABLE_FAILURE_MARKERS
            )
            if not any(marker in reason for marker in _NEVER_PENALIZE_MARKERS) and any(
                marker in reason for marker in markers
            ):
                gate_failures += 1
                continue
        if not icp_has_intent_signals:
            continue
        details = row.get("intent_signals_detail")
        if not isinstance(details, Sequence) or isinstance(details, (str, bytes)):
            continue
        primary_verified = False
        verifier_failed = False
        for detail in details:
            if not isinstance(detail, Mapping):
                continue
            verdict = detail.get("judge_verdict")
            if isinstance(verdict, Mapping) and (
                str(verdict.get("decision") or "") == "rejected_verifier_error"
                or bool(verdict.get("error_class"))
            ):
                verifier_failed = True
            try:
                index = int(detail.get("matched_icp_signal", -1))
            except (TypeError, ValueError):
                continue
            if index == 0 and float(detail.get("after_decay") or 0.0) > 0.0:
                primary_verified = True
                break
        if details and not primary_verified and not verifier_failed:
            unverified_primary += 1
    return gate_failures, unverified_primary


def fp_penalty_total_from_breakdowns(
    breakdowns: Sequence[Mapping[str, Any]], icp: Mapping[str, Any]
) -> float:
    gate, primary = count_penalizable_false_positives(
        breakdowns,
        icp_has_intent_signals=bool(
            icp.get("intent_signals") or icp.get("intent_signal")
        ),
    )
    return float(gate + primary) * FP_PENALTY_POINTS


def competition_icp_score_from_company_scores(
    scores: Sequence[float], *, requested_count: int, fp_penalty_total: float = 0.0
) -> float:
    """Use the same capped score arithmetic as the Arena."""

    count = max(1, min(MAX_COMPANY_GOAL, int(requested_count)))
    normalized = float(
        per_icp_normalized_score(
            sorted((float(value or 0.0) for value in scores), reverse=True)[:count],
            max_leads=count,
        )
    )
    return max(0.0, normalized - max(0.0, float(fp_penalty_total)) / count)


def competition_score_from_breakdowns(
    icp: Mapping[str, Any],
    breakdowns: Sequence[Mapping[str, Any]],
    *,
    fp_penalty_points: float = FP_PENALTY_POINTS,
    fp_unverified_primary_penalty_points: float = FP_PENALTY_POINTS,
    score_floor: float = 0.0,
    fit_receipt_authoritative: bool = False,
) -> dict[str, Any]:
    """Calculate one ICP score for both the baseline and miner bundles."""

    goal = _company_goal(icp)
    rows = [dict(row) for row in breakdowns]
    gate, primary = count_penalizable_false_positives(
        rows,
        icp_has_intent_signals=bool(
            icp.get("intent_signals") or icp.get("intent_signal")
        ),
        fit_receipt_authoritative=fit_receipt_authoritative,
    )
    company_scores = [float(row.get("final_score") or 0.0) for row in rows]
    normalized = float(
        per_icp_normalized_score(company_scores[:goal], max_leads=goal)
    )
    penalty = (
        gate * max(0.0, float(fp_penalty_points))
        + primary * max(0.0, float(fp_unverified_primary_penalty_points))
    ) / goal
    return {
        "per_icp_score": max(float(score_floor), normalized - penalty),
        "fp_gate_count": gate,
        "fp_unverified_primary_count": primary,
        "company_goal": goal,
        "company_scores": company_scores,
    }
