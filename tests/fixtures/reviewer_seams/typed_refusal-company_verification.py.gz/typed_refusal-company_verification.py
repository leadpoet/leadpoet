"""
Qualification System: Company-existence verification (company-mode only)

This is the company-mode equivalent of ``db_verification.py``.  In
lead-mode the model is required to point at a real row in the published
leads table; we verify by comparing field-for-field against Supabase.

Company-mode has no leads table to compare against — the model is asked
to surface companies from the open web.  Instead, we verify that the
``CompanyOutput.company_website`` resolves to a live, real-looking
company page that actually mentions the claimed company name.  This
plays the same anti-gaming role as DB verification: it makes it
expensive to invent a fictitious company.

Design constraints:

* Cheap (single HTTP GET, ~3-5s budget).  Validators score many leads
  back-to-back; a slow verification step bottlenecks the pipeline.
* No paid APIs.  Apify / LinkedIn / etc. are deliberately excluded —
  baking those into base-miner scoring would force every miner who
  builds on the model to take on licensing risk.  See
  ``gateway/qualification/models.py::CompanyOutput`` for the rationale.
* Three-state outcome.  A verified homepage-name binding is ``match``;
  a parked or contradicted identity is ``mismatch``; transport failure or
  insufficient evidence is ``unavailable``.  A domain that resembles the
  company name is never sufficient proof by itself.

Public API:
    verify_company_exists(company_name, company_website, timeout_secs=5,
                          company_linkedin=...) -> CompanyFitDecisionResult
"""

from __future__ import annotations

import asyncio
import codecs
from html.parser import HTMLParser
import json
import os
import logging
import re
from typing import Mapping, Optional
from urllib.parse import urljoin, urlsplit, urlunsplit

import aiohttp

from leadpoet_verifier.identity.normalization import NormalizationError, normalize_url
from qualification.competition_models import public_http_url
from qualification.scoring.company_fit_decision import (
    CompanyFitDecisionResult,
    company_fit_match,
    company_fit_mismatch,
    company_fit_unavailable,
    evaluate_company_identity,
    observed_linkedin_ampersand_slug,
    _company_name,
)


from qualification.scoring.verification_helpers import (
    _VisibleHTMLTextParser,
    _css_hidden_selectors,
)


logger = logging.getLogger(__name__)


# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

_HTTP_TIMEOUT_SECS = 5
# Large first-party sites can place identity metadata after bundled style data.
# Keep the single fetch bounded while covering the observed 1.5 MB homepage.
_MAX_BYTES = 2_000_000
_TRANSIENT_FETCH_ATTEMPTS = 2
_TRANSIENT_FETCH_RETRY_DELAY_SECS = 0.25
_MAX_ORGANIZATION_LEGAL_NAME_ALIASES = 3
_MAX_ORGANIZATION_NAME_LENGTH = 200
MAX_HOMEPAGE_NAVIGATION_LOCATORS = 40
MAX_HOMEPAGE_NAVIGATION_LABEL_LENGTH = 200
MAX_HOMEPAGE_NAVIGATION_TOTAL_CHARACTERS = 6_000
VERIFIED_REBRAND_REDIRECT_KEY = "verified_rebrand_redirect"
_HTML_ENCODING_SNIFF_BYTES = 1024
_MIN_NON_HTML_HOMEPAGE_CHARS = 50
_IDENTITY_SOURCE_HOST_LABELS = frozenset({"media", "news", "newsroom", "press"})
_HTML_ELEMENT_RE = re.compile(r"<\s*!doctype\s+html\b|<\s*/?\s*[a-z][a-z0-9:-]*\b", re.I)

# Python also exposes binary transforms as codecs. This explicit text-codec
# subset prevents an untrusted HTTP or HTML label from selecting one of them.
_SAFE_HTML_CODECS = frozenset({
    "ascii",
    "big5",
    "cp866",
    "cp874",
    *(f"cp125{index}" for index in range(9)),
    "euc_jp",
    "euc_kr",
    "gb18030",
    "gbk",
    *(f"iso8859-{index}" for index in (*range(1, 12), *range(13, 17))),
    "iso2022_jp",
    "koi8-r",
    "koi8-u",
    "mac-cyrillic",
    "mac-roman",
    "shift_jis",
    "utf-8",
    "utf-16",
    "utf-16-be",
    "utf-16-le",
})
_CHARSET_PARAMETER_RE = re.compile(
    r"(?:^|;)\s*charset\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^;\s]*))",
    re.IGNORECASE,
)

# Headers that look like a real browser.  Some company sites refuse
# default ``python-aiohttp/...`` user agents with 403, which would
# falsely fail otherwise-legitimate companies.
_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}

# Patterns indicating a parked / for-sale / GoDaddy-style landing page.
# Hit any of these and the company verification fails, since the URL
# is not a real company website even if it returns HTTP 200.
_PARKED_DOMAIN_PATTERNS = [
    r"\bthis domain (?:is|may be) for sale\b",
    r"\bbuy this domain\b",
    r"\bdomain.*available for purchase\b",
    r"\bregister(?:ed)? this domain\b",
    r"\bsedo(?:parking)?\b",
    r"\bgodaddy\b.*\bparked\b",
    r"\bnamecheap\b.*\bparked\b",
    r"\bhostgator\b.*\bdefault\b",
    # Keep these terms local. Minified product pages can mention a coming-soon
    # feature and an unrelated email domain hundreds of kilobytes later.
    r"\bcoming soon\b.{0,80}\bdomain\b",
    r"\bdefault web site page\b",
]
_PARKED_DOMAIN_RE = re.compile("|".join(_PARKED_DOMAIN_PATTERNS), re.IGNORECASE)
_COPYRIGHT_LEGAL_NAME_RE = re.compile(
    r"(?:©|\bcopyright\b)\s*"
    r"(?:\d{4}(?:\s*[-\N{EN DASH}]\s*\d{4})?\s*)?"
    r"(?P<name>[a-z][a-z0-9&.,'’ -]{1,180}?\b(?:limited|ltd\.?|"
    r"incorporated|inc\.?|corporation|corp\.?|llc|plc|pty limited|"
    r"pty ltd\.?))"
    r"(?=\s+(?:abn|acn|all rights reserved)\b|[\s.]*$)",
    re.IGNORECASE,
)
_CURRENT_EXCHANGE_SLASH_PROFILE_RE = re.compile(
    r"(?:nyse|nasdaq)\s*/\s*(?P<ticker>[A-Z][A-Z0-9.-]{0,9})\s+"
    r"(?P<issuer>[A-Z][A-Z0-9&.'’+ -]{2,100})",
    re.I,
)
_CURRENT_EXCHANGE_LABEL_PROFILE_RE = re.compile(
    r"(?P<issuer>[A-Z][A-Za-z0-9&,.'’+ -]{2,100}?)\s+"
    r"(?P<exchange>New\s+York\s+Stock\s+Exchange|NYSE|NASDAQ)\s*:\s*"
    r"(?P<ticker>[A-Z][A-Z0-9.-]{0,9})",
    re.I,
)
_CURRENT_EXCHANGE_PREFIX_PROFILE_RE = re.compile(
    r"(?P<exchange>NYSE|NASDAQ)\s*:\s*"
    r"(?P<ticker>[A-Z][A-Z0-9.-]{1,9})",
    re.I,
)
# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def verified_brand_legal_name_initialism(
    brand: object,
    legal_name: object,
    verified_legal_name_aliases: object,
) -> bool:
    """Bind a brand initialism to a homepage-corroborated full legal name."""

    brand_key = _company_name(brand)
    legal_key = _company_name(legal_name)
    words = re.findall(r"[a-z0-9]+", str(legal_name or "").casefold())
    while len(words) > 1 and _company_name(" ".join(words[:-1])) == legal_key:
        words.pop()
    aliases = (
        verified_legal_name_aliases
        if isinstance(verified_legal_name_aliases, list)
        else []
    )
    alias_words: list[list[str]] = []
    for alias in aliases[:_MAX_ORGANIZATION_LEGAL_NAME_ALIASES]:
        if not isinstance(alias, str) or not alias.strip():
            continue
        alias_key = _company_name(alias)
        tokens = re.findall(r"[a-z0-9]+", alias.casefold())
        while len(tokens) > 1 and _company_name(" ".join(tokens[:-1])) == alias_key:
            tokens.pop()
        alias_words.append(tokens)
    return bool(
        2 <= len(brand_key) <= 10
        and len(words) >= 2
        and "".join(word[0] for word in words) == brand_key
        and any(tokens[:len(words)] == words for tokens in alias_words)
    )


def verified_brand_formal_legal_name(brand: object, legal_name: object) -> bool:
    """Match an exact brand to its formal legal name, with optional ``The``.

    This does not infer an alias from a shared prefix. The caller must verify
    the same first-party domain and LinkedIn identity independently.
    """

    formal_suffixes = {
        "corporation", "corp", "incorporated", "inc", "limited", "ltd",
        "llc", "plc",
    }
    brand_words = re.findall(r"[a-z0-9]+", str(brand or "").casefold())
    legal_words = re.findall(r"[a-z0-9]+", str(legal_name or "").casefold())
    if (
        not brand_words
        or brand_words[-1] in formal_suffixes
        or len(legal_words) < 2
    ):
        return False
    if legal_words[-1] not in formal_suffixes:
        return False
    legal_core = legal_words[:-1]
    return bool(
        legal_core == brand_words or legal_core == ["the", *brand_words]
    )


def current_exchange_profile_names_issuer(
    quote: str,
    identity_names: list[str] | tuple[str, ...] | set[str],
    *,
    allow_initials: bool = True,
) -> bool:
    """Bind a current exchange quote-card layout to its exact issuer identity."""

    labeled_price = bool(re.search(
        r"\b(?:last|open|prev\.?\s*close|volume|market\s+cap)\s*[:$]?\s*"
        r"\$?\d+(?:[,.]\d+)*(?:\.\d+)?[kmb]?\b|"
        r"\bstock\s+price\s+(?:increased|decreased|unchanged)\s+by\s+"
        r"[+-]?\$?\d+(?:\.\d+)?\b",
        quote,
        re.I,
    ))
    currency_priced_ticker_ends = {
        match.end()
        for match in _CURRENT_EXCHANGE_PREFIX_PROFILE_RE.finditer(quote)
        if (price := re.match(r"\s+\$\d+(?:[,.]\d+)*\b", quote[match.end():]))
        and not re.match(
            r"\s*\(?\s*(?:hypothetical|planned|proposed|expected|projected|"
            r"target|ipo|offering)\b",
            quote[match.end() + price.end():],
            re.I,
        )
    }
    if re.search(
        r"\b(?:delisted|no\s+longer\s+listed)\b|"
        r"\b(?:ceased|stopped)\s+trading\b|"
        r"\b(?:taken|went|became)\s+private\b",
        quote,
        re.I,
    ) or not (labeled_price or currency_priced_ticker_ends):
        return False
    names = {
        str(value).strip() for value in identity_names
        if str(value or "").strip()
    }
    def issuer_matches(issuer: str, *, slash_form: bool) -> bool:
        if slash_form:
            issuer = re.split(r"\s+\d", issuer, maxsplit=1)[0]
        else:
            navigation = re.search(
                r"\s+skip\s+to\s+(?:main\s+)?(?:content|navigation)\s*$",
                issuer,
                re.I,
            )
            if navigation:
                issuer = issuer[:navigation.start()].rsplit(" - ", 1)[-1]
            issuer = re.sub(
                r"^(?:quote\s*&\s*chart\s+)?(?:chart\s+)?",
                "",
                issuer,
                flags=re.I,
            )
        normalized_issuer = _company_name(issuer)
        issuer_structural_terms = set(re.findall(
            r"\b(?:holdings?|subsidiar(?:y|ies)|group)\b",
            issuer.casefold(),
        ))
        issuer_initials = "".join(
            token[0] for token in re.findall(r"[A-Za-z0-9]+", issuer)
            if token.casefold() not in {
                "inc", "incorporated", "corp", "corporation",
            }
        ).casefold()
        return any(
            (
                normalized_name == normalized_issuer
                and issuer_structural_terms == set(re.findall(
                    r"\b(?:holdings?|subsidiar(?:y|ies)|group)\b",
                    str(name).casefold(),
                ))
            )
            or (
                allow_initials
                and not issuer_structural_terms
                and len(normalized_name) >= 3
                and normalized_name == issuer_initials
            )
            for name in names
            if (normalized_name := _company_name(name))
        )

    def navigation_label_for_direct_ticker(issuer: str) -> bool:
        """Identify an issuer-owned IR title accidentally joined to nav text."""

        return any(
            re.fullmatch(
                rf"\s*{re.escape(name)}\s*-\s*investor relations"
                r"(?:\s+(?:skip to main content|investor relations|search))*\s*",
                issuer,
                re.I,
            )
            for name in names
        )

    labeled_matches = list(_CURRENT_EXCHANGE_LABEL_PROFILE_RE.finditer(quote))
    for match in _CURRENT_EXCHANGE_SLASH_PROFILE_RE.finditer(quote):
        if labeled_price and issuer_matches(str(match.group("issuer") or ""), slash_form=True):
            return True
    for match in labeled_matches:
        if not labeled_price and match.end() not in currency_priced_ticker_ends:
            continue
        if issuer_matches(str(match.group("issuer") or ""), slash_form=False):
            return True
    for match in _CURRENT_EXCHANGE_PREFIX_PROFILE_RE.finditer(quote):
        if not labeled_price and match.end() not in currency_priced_ticker_ends:
            continue
        ticker_key = _company_name(match.group("ticker"))
        if not any(_company_name(name) == ticker_key for name in names):
            continue
        # A direct ticker card may follow navigation text, as on issuer IR
        # pages. Do not let that text consume the direct match. An explicit
        # nearby issuer label still owns the attribution and blocks a ticker
        # collision when it names a different company.
        conflicting_label = any(
            labeled.end() == match.end()
            and not issuer_matches(
                str(labeled.group("issuer") or ""), slash_form=False,
            )
            and not navigation_label_for_direct_ticker(
                str(labeled.group("issuer") or ""),
            )
            for labeled in labeled_matches
        )
        if not conflicting_label:
            return True
    return False

def _upgrade_plain_http_company_url(company_website: str) -> str:
    """Upgrade a conventional HTTP company URL to the V2 HTTPS transport.

    Only the default HTTP port is eligible.  Explicit nonstandard ports,
    credentials, malformed URLs, and every non-HTTP scheme are left unchanged
    so the measured provider transport can reject them fail-closed.
    """

    value = str(company_website or "").strip()
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except (TypeError, ValueError):
        return value
    if (
        parsed.scheme.lower() != "http"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or port not in (None, 80)
    ):
        return value
    host = parsed.hostname
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    return urlunsplit(("https", host, parsed.path, parsed.query, parsed.fragment))


def _charset_parameter(value: object) -> str:
    """Return one declared charset label from a Content-Type value."""

    match = _CHARSET_PARAMETER_RE.search(str(value or ""))
    if match is None:
        return ""
    return next((item.strip() for item in match.groups() if item), "")


class _EarlyMetaCharsetParser(HTMLParser):
    """Read the first real HTML charset declaration from the bounded prefix."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.charset = ""

    def handle_starttag(self, tag: str, attrs) -> None:
        if self.charset or tag.casefold() != "meta":
            return
        attributes = {}
        for key, value in attrs:
            # HTML tokenization keeps the first duplicate attribute.
            attributes.setdefault(
                str(key or "").casefold(), str(value or "").strip()
            )
        direct = attributes.get("charset", "")
        candidate = direct
        if (
            not candidate
            and attributes.get("http-equiv", "").casefold() == "content-type"
        ):
            candidate = _charset_parameter(attributes.get("content", ""))
        # An invalid declaration does not hide a later valid declaration.
        self.charset = _safe_html_codec(candidate)
        if self.charset.startswith("utf-16"):
            # HTML meta declarations cannot select UTF-16; only BOM/HTTP can.
            self.charset = "utf-8"


def _early_meta_charset(raw: bytes) -> str:
    parser = _EarlyMetaCharsetParser()
    try:
        # HTML encoding labels are ASCII. Latin-1 preserves every source byte
        # while HTMLParser excludes declarations in comments and script data.
        parser.feed(raw[:_HTML_ENCODING_SNIFF_BYTES].decode("latin-1"))
        parser.close()
    except (AssertionError, ValueError):
        return ""
    return parser.charset


def _safe_html_codec(label: str) -> str:
    try:
        canonical = codecs.lookup(str(label or "").strip()).name
    except (LookupError, TypeError, ValueError):
        return ""
    return canonical if canonical in _SAFE_HTML_CODECS else ""


def _decode_homepage_html(raw: bytes, content_type: object = "") -> str:
    """Decode bounded homepage bytes without probabilistic encoding guesses."""

    value = bytes(raw)
    for marker, encoding in (
        (codecs.BOM_UTF8, "utf-8-sig"),
        (codecs.BOM_UTF16_BE, "utf-16"),
        (codecs.BOM_UTF16_LE, "utf-16"),
    ):
        if value.startswith(marker):
            return value.decode(encoding, errors="replace")

    encoding = _safe_html_codec(_charset_parameter(content_type))
    if not encoding:
        encoding = _safe_html_codec(_early_meta_charset(value))
    try:
        return value.decode(encoding or "utf-8", errors="replace")
    except UnicodeError:
        return value.decode("utf-8", errors="replace")


def _content_type_header(headers: object) -> object:
    if not hasattr(headers, "items"):
        return ""
    for name, value in headers.items():
        if str(name).casefold() == "content-type":
            return value
    return ""


def _homepage_body_is_unusable(text: str) -> bool:
    """Recognize only empty or tiny non-HTML fetch placeholders."""

    body = str(text or "").strip()
    return not body or (
        len(body) < _MIN_NON_HTML_HOMEPAGE_CHARS
        and _HTML_ELEMENT_RE.search(body) is None
    )


def _registrable_domain(url: str) -> str:
    """Extract the PSL-aware registrable domain from an HTTP(S) URL.

    ``https://www.ExampleCo.com/about`` -> ``exampleco.com``.
    """
    return normalize_url(url.strip()).domain.registrable_domain


def _normalize_for_match(s: str) -> str:
    """Lowercase + strip non-alphanumerics so 'Example, Co.' matches 'exampleco'."""
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def _name_appears(haystack: str, company_name: str) -> bool:
    """Does ``company_name`` plausibly appear in ``haystack``?

    Tolerant of legal suffixes ('Inc', 'Ltd', 'LLC'), case, punctuation,
    and the company name being split across HTML tags.  We collapse both
    sides to alphanumerics-only before checking — same idea as company
    name fuzzy matching in pre_checks.
    """
    if not company_name or not haystack:
        return False

    # Strip only terminal legal suffixes from the claimed name. Tokens such
    # as "Group" and "AG" can be meaningful leading name terms.
    legal_suffixes = {
        "inc", "incorporated", "llc", "ltd", "limited", "corp",
        "corporation", "co", "company", "gmbh", "sa", "bv", "plc",
        "holdings", "group", "ag", "nv", "oy", "ab", "as", "pty",
        "pte", "kk", "srl", "spa",
    }
    words = re.findall(r"[a-z0-9]+", str(company_name or "").casefold())
    while words and words[-1] in legal_suffixes:
        words.pop()
    needle = "".join(words)
    if len(needle) < 3:
        # Avoid spurious matches on extremely short normalized names.
        # In practice, requiring 3+ characters costs us nothing; companies
        # that short are vanishingly rare and would need stronger signals
        # anyway.
        needle = _normalize_for_match(company_name)
    hay = _normalize_for_match(haystack)
    return bool(needle) and needle in hay


def _domain_matches_name(company_website: str, company_name: str) -> bool:
    """Legacy diagnostic heuristic; never sufficient for a fit decision."""
    try:
        domain = _registrable_domain(company_website)
    except Exception:
        return False
    if not domain:
        return False
    # Take only the part before the public suffix (e.g. 'exampleco' from
    # 'exampleco.com' or 'exampleco' from 'exampleco.co.uk').  This is a
    # diagnostic heuristic only. The verifier never uses it as proof.
    parts = domain.split(".")
    if len(parts) >= 2:
        base = parts[-2]
    else:
        base = domain
    return _name_appears(base, company_name)


def _canonical_linkedin_company_url(value: str) -> str:
    """Return a direct, canonical LinkedIn company URL or an empty string."""

    raw = str(value or "").strip()
    if raw.startswith("//"):
        raw = f"https:{raw}"
    try:
        parsed = urlsplit(raw)
    except (TypeError, ValueError):
        return ""
    host = str(parsed.hostname or "").casefold().removeprefix("www.")
    parts = [part for part in parsed.path.split("/") if part]
    if (
        parsed.scheme.casefold() not in {"http", "https"}
        or parsed.username is not None
        or parsed.password is not None
        or not (host == "linkedin.com" or host.endswith(".linkedin.com"))
        or len(parts) < 2
        or parts[0].casefold() != "company"
    ):
        return ""
    slug = parts[1].casefold()
    ampersand_slug = observed_linkedin_ampersand_slug(slug)
    if ampersand_slug:
        return f"https://www.linkedin.com/company/{ampersand_slug}"
    if not re.fullmatch(r"[a-z0-9][a-z0-9._%+-]{0,99}", slug):
        return ""
    return f"https://www.linkedin.com/company/{slug}"


class _OrganizationIdentityOverflow(ValueError):
    """A JSON-LD document exceeded the bounded identity inspection."""


def _organization_identity_records(value) -> list[dict[str, object]]:
    """Extract bounded root Organization identity records from JSON-LD."""

    try:
        document = json.loads(value)
    except (TypeError, ValueError, json.JSONDecodeError):
        return []

    roots = document if isinstance(document, list) else [document]
    if len(roots) > 20:
        raise _OrganizationIdentityOverflow
    candidates: list[object] = []
    for root in roots:
        if not isinstance(root, dict):
            continue
        candidates.append(root)
        graph = root.get("@graph")
        if isinstance(graph, list):
            if len(graph) > 20:
                raise _OrganizationIdentityOverflow
            candidates.extend(graph)

    records: list[dict[str, object]] = []
    for node in candidates:
        if not isinstance(node, dict):
            continue
        raw_type = node.get("@type", "")
        types = raw_type if isinstance(raw_type, list) else [raw_type]
        if not any(str(item or "").casefold() == "organization" for item in types):
            continue
        raw_same_as = node.get("sameAs", [])
        same_as_candidates = (
            raw_same_as if isinstance(raw_same_as, list) else [raw_same_as]
        )
        linkedins = list(
            dict.fromkeys(
                canonical
                for candidate in same_as_candidates[:20]
                if (canonical := _canonical_linkedin_company_url(candidate))
            )
        )[:10]
        records.append(
            {
                "name": node.get("name"),
                "legal_name": node.get("legalName"),
                "url": node.get("url"),
                "linkedin_urls": linkedins,
            }
        )
        if len(records) > 10:
            raise _OrganizationIdentityOverflow
    return records


def _organization_same_as_urls(value) -> list[str]:
    """Extract LinkedIn URLs from nested JSON-LD Organization ``sameAs`` data."""

    urls: list[str] = []

    try:
        document = json.loads(value)
    except (TypeError, ValueError, json.JSONDecodeError):
        return []

    def visit(node) -> None:
        if isinstance(node, dict):
            raw_type = node.get("@type", "")
            types = raw_type if isinstance(raw_type, list) else [raw_type]
            is_organization = any(
                str(item or "").casefold() == "organization" for item in types
            )
            if is_organization:
                raw_same_as = node.get("sameAs", [])
                candidates = (
                    raw_same_as if isinstance(raw_same_as, list) else [raw_same_as]
                )
                for candidate in candidates:
                    canonical = _canonical_linkedin_company_url(candidate)
                    if canonical:
                        urls.append(canonical)
            for child in node.values():
                visit(child)
        elif isinstance(node, list):
            for child in node:
                visit(child)

    visit(document)
    return list(dict.fromkeys(urls))[:10]


def _is_https_url(value: str) -> bool:
    """Whether a final response URL is an absolute HTTPS URL without creds."""

    try:
        parsed = urlsplit(str(value or "").strip())
    except (TypeError, ValueError):
        return False
    return bool(
        parsed.scheme.casefold() == "https"
        and parsed.hostname
        and parsed.username is None
        and parsed.password is None
    )


def _homepage_company_linkedin_urls(page_text: str) -> list[str]:
    """Return bounded LinkedIn identities from parsed hrefs or Organization JSON-LD."""

    parser = _HomepageIdentityParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return []
    return list(dict.fromkeys(parser.linkedin_urls))[:10]


def _linked_identity_source_url(
    page_text: str,
    *,
    base_url: str,
    registrable_domain: str,
) -> str:
    """Return one linked first-party newsroom root, without guessing a path."""

    parser = _HomepageIdentityParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return ""

    for href in parser.source_hrefs:
        try:
            absolute = urljoin(base_url, href)
            parsed = urlsplit(absolute)
            candidate_port = parsed.port
            candidate_domain = _registrable_domain(absolute)
        except (NormalizationError, TypeError, ValueError):
            continue
        if (
            _is_https_url(absolute)
            and candidate_port in (None, 443)
            and candidate_domain == registrable_domain
            and parsed.path.rstrip("/") == ""
            and str(parsed.hostname or "").casefold().split(".")[0]
            in _IDENTITY_SOURCE_HOST_LABELS
        ):
            return urlunsplit(
                ("https", parsed.netloc.casefold(), "/", parsed.query, "")
            )
    return ""


class _HomepageIdentityParser(HTMLParser):
    """Extract bounded first-party name metadata without trusting input text."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._in_title = False
        self._title_seen = False
        self._foreign_depth = 0
        self._title_parts: list[str] = []
        self.metadata_names: list[str] = []
        self.copyright_legal_names: list[str] = []
        self.linkedin_urls: list[str] = []
        self.source_hrefs: list[str] = []
        self.organization_records: list[dict[str, object]] = []
        self.organization_identity_overflow = False
        self._json_ld_parts: list[str] | None = None
        self._nonvisible_depth = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        tag_name = tag.casefold()
        attributes = {
            str(key or "").casefold(): str(value or "").strip()
            for key, value in attrs
        }
        if tag_name in {"script", "style", "template"}:
            self._nonvisible_depth += 1
        if tag_name in {"svg", "math"}:
            self._foreign_depth += 1
        if tag_name == "title":
            # The document has one title. SVG/MathML accessibility labels and
            # inert template titles are not additional company-name metadata.
            self._in_title = not (
                self._title_seen or self._foreign_depth or self._nonvisible_depth
            )
            self._title_seen |= self._in_title
            return
        if tag_name in {"a", "link"}:
            href = attributes.get("href", "")
            if (
                tag_name == "a"
                and href
                and len(href) <= 2048
            ):
                self.source_hrefs.append(href)
            linkedin = _canonical_linkedin_company_url(href)
            if linkedin:
                self.linkedin_urls.append(linkedin)
        if tag_name == "script":
            script_type = attributes.get("type", "").split(";", 1)[0].casefold()
            if script_type == "application/ld+json":
                self._json_ld_parts = []
            return
        if tag_name != "meta":
            return
        key = (
            attributes.get("property")
            or attributes.get("name")
            or attributes.get("itemprop")
            or ""
        ).casefold()
        if key in {"og:site_name", "application-name"}:
            content = attributes.get("content", "")
            if content:
                self.metadata_names.append(content[:200])

    def handle_endtag(self, tag: str) -> None:
        tag_name = tag.casefold()
        if tag_name == "title":
            self._in_title = False
        elif tag_name == "script" and self._json_ld_parts is not None:
            json_ld = "".join(self._json_ld_parts)
            try:
                records = _organization_identity_records(json_ld)
            except _OrganizationIdentityOverflow:
                self.organization_identity_overflow = True
                records = []
            self.organization_records.extend(records)
            self.linkedin_urls.extend(_organization_same_as_urls(json_ld))
            self._json_ld_parts = None
        if tag_name in {"script", "style", "template"}:
            self._nonvisible_depth = max(0, self._nonvisible_depth - 1)
        if tag_name in {"svg", "math"}:
            self._foreign_depth = max(0, self._foreign_depth - 1)

    def handle_data(self, data: str) -> None:
        if self._in_title and data.strip():
            self._title_parts.append(data.strip())
        if self._json_ld_parts is not None:
            self._json_ld_parts.append(data)
        if self._nonvisible_depth == 0:
            self.copyright_legal_names.extend(
                match.group("name").strip()[:200]
                for match in _COPYRIGHT_LEGAL_NAME_RE.finditer(data[:500])
            )

    @property
    def title(self) -> str:
        return " ".join(self._title_parts).strip()[:300]


class _HomepageNavigationParser(HTMLParser):
    """Collect bounded visible anchor targets and labels in document order."""

    _HIDDEN_ELEMENTS = frozenset({"script", "style", "template", "noscript"})
    _VOID_ELEMENTS = frozenset({
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    })

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[tuple[str, str]] = []
        self._stack: list[tuple[str, bool]] = []
        self._hidden_depth = 0
        self._href = ""
        self._label_parts: list[str] = []

    @staticmethod
    def _attributes(attrs) -> dict[str, str]:
        values: dict[str, str] = {}
        for key, value in attrs:
            values.setdefault(
                str(key or "").casefold(), str(value or "").strip()
            )
        return values

    @staticmethod
    def _element_is_hidden(attributes: Mapping[str, str]) -> bool:
        style = re.sub(r"\s+", "", attributes.get("style", "").casefold())
        return bool(
            "hidden" in attributes
            or attributes.get("aria-hidden", "").casefold() in {"true", "1"}
            or "display:none" in style
            or "visibility:hidden" in style
        )

    def handle_starttag(self, tag: str, attrs) -> None:
        tag_name = tag.casefold()
        attributes = self._attributes(attrs)
        if tag_name in self._VOID_ELEMENTS:
            return
        hidden = bool(
            tag_name in self._HIDDEN_ELEMENTS
            or self._element_is_hidden(attributes)
        )
        self._stack.append((tag_name, hidden))
        if hidden:
            self._hidden_depth += 1
        if (
            tag_name == "a"
            and not self._hidden_depth
        ):
            self._href = attributes.get("href", "")
            self._label_parts = []

    def handle_endtag(self, tag: str) -> None:
        tag_name = tag.casefold()
        if tag_name in self._VOID_ELEMENTS:
            return
        if tag_name == "a" and self._href:
            if len(self.links) < 500:
                self.links.append((self._href, " ".join(self._label_parts)))
            self._href = ""
            self._label_parts = []
        match = next(
            (
                index for index in range(len(self._stack) - 1, -1, -1)
                if self._stack[index][0] == tag_name
            ),
            None,
        )
        if match is None:
            return
        popped = self._stack[match:]
        del self._stack[match:]
        self._hidden_depth -= sum(hidden for _tag, hidden in popped)
        self._hidden_depth = max(0, self._hidden_depth)

    def handle_data(self, data: str) -> None:
        if self._href and not self._hidden_depth:
            self._label_parts.append(data)


class _InlineFooterCopyrightParser(_VisibleHTMLTextParser):
    """Read one visible footer paragraph across bounded inline text nodes."""

    _INLINE = frozenset({"span", "b", "strong", "em", "i", "small"})
    # Footer text is the intended identity source; shared visibility rules
    # still exclude its hidden ancestors, descendants and stylesheet selectors.
    _HIDDEN_ELEMENTS = (_VisibleHTMLTextParser._HIDDEN_ELEMENTS - {"footer"}) | {"svg", "math"}

    def __init__(self, page_text: str) -> None:
        hidden_classes, hidden_ids = _css_hidden_selectors(page_text)
        super().__init__(hidden_classes=hidden_classes, hidden_ids=hidden_ids)
        self.names: list[str] = []
        self._parts: list[str] | None = None
        self._size = 0

    def _is_hidden(self, tag: str, attrs) -> bool:
        return "inert" in self._attribute_map(attrs) or super()._is_hidden(tag, attrs)

    def _finish_paragraph(self) -> None:
        if self._parts is not None:
            text = " ".join(self._parts)
            self.names.extend(
                match.group("name").strip()[:200]
                for match in _COPYRIGHT_LEGAL_NAME_RE.finditer(text)
                # Do not treat an interrupted name as a complete copyright.
                if re.match(r"[.\s]*all rights reserved\b", text[match.end():], re.I)
            )
        self._parts = None
        self._size = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        tag = tag.casefold()
        super().handle_starttag(tag, attrs)
        if self._parts is not None and (tag not in self._INLINE or self._hidden_depth):
            self._finish_paragraph()
        if (tag == "p" and not self._hidden_depth
                and any(parent == "footer" for parent, _hidden, _start in self._stack)):
            self._parts = []

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() not in self._INLINE:
            self._finish_paragraph()
        super().handle_endtag(tag)

    def handle_data(self, data: str) -> None:
        if self._parts is not None and not self._hidden_depth:
            self._size += len(data)
            if self._size > 500:
                self._parts = None
            else:
                self._parts.append(data)


def _inline_footer_copyright_names(
    page_text: str, existing_names: list[str],
) -> list[str]:
    page_text = str(page_text or "")[:_MAX_BYTES]
    parser = _InlineFooterCopyrightParser(page_text)
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return []
    # Multiple legal owners do not establish one exact company identity.
    names = list(dict.fromkeys(parser.names))
    return names if len({re.sub(r"[^a-z0-9]+", "", name.casefold())
                         for name in [*names, *existing_names]}) == 1 else []


def _commercial_terms_navigation_locator(url: str, label: str) -> bool:
    """Recognize a legal-source locator, never infer its commercial contents."""

    path_parts = [part.casefold() for part in urlsplit(url).path.split("/") if part]
    if not path_parts or any(part in {
        "blog", "blogs", "news", "newsroom", "articles", "insights",
    } for part in path_parts):
        return False
    source_names = {
        "terms", "terms-of-use", "terms-of-service", "terms-and-conditions",
        "terms-conditions", "subscription-agreement", "eula", "license",
        "license-agreement", "software-license-agreement",
    }
    source_path = re.sub(r"\.(?:html?|pdf)$", "", path_parts[-1]).replace("_", "-")
    source_label = "-".join(re.findall(r"[a-z]+", label.casefold()))
    return source_path in source_names or (
        any(part in {"legal", "agreements"} for part in path_parts[:-1])
        and source_label in source_names
    )


def _recognized_careers_board_locator(url: str, label: str) -> tuple[str, str] | None:
    """Identify a careers locator; callers must separately prove its source."""
    if not re.search(r"\b(careers?|jobs?|apply|positions?|openings?|open roles|join (?:us|our team))\b", label, re.I):
        return None
    # Reuse the exact Greenhouse/Ashby/Lever tenant parsers used for hiring.
    # A recognized board or matching tenant name alone is never ownership.
    from qualification.scoring.intent_verification_three_stage import _ats_board_identity
    return _ats_board_identity(url)


def _homepage_navigation_locators(
    page_text: str,
    *,
    final_url: str,
    verified_domain: str,
) -> list[dict[str, str]]:
    """Resolve visible company navigation and scoped careers locators."""

    parser = _HomepageNavigationParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return []

    candidates: list[tuple[int, dict[str, str]]] = []
    seen: set[str] = set()
    industry_review = bool(os.environ.get("ARENA_INDUSTRY_EVIDENCE_MODEL", "").strip())
    for href, raw_label in parser.links:
        label = " ".join(str(raw_label or "").split())
        if not label or len(label) > MAX_HOMEPAGE_NAVIGATION_LABEL_LENGTH:
            continue
        try:
            absolute = urljoin(final_url, str(href or "").strip())
            parsed = urlsplit(absolute)
            port = parsed.port
        except (TypeError, ValueError):
            continue
        if (
            parsed.scheme.casefold() != "https"
            or not parsed.hostname
            or parsed.username is not None
            or parsed.password is not None
            or parsed.fragment
            or (port is not None and port != 443)
            or len(absolute) > 2000
            or not absolute.isascii()
            or any(character.isspace() for character in absolute)
        ):
            continue
        canonical = urlunsplit(
            ("https", parsed.netloc.casefold(), parsed.path, parsed.query, "")
        )
        try:
            if _registrable_domain(canonical) != verified_domain and not (
                industry_review
                and _registrable_domain(final_url) == verified_domain
                and _recognized_careers_board_locator(canonical, label)
            ):
                continue
        except Exception:
            continue
        if canonical in seen:
            continue
        seen.add(canonical)
        # Large menus can hide relevant commercial and company pages after the
        # first 40 links. Preserve these locators within the existing limits.
        words = set(re.findall(
            r"[a-z]+", f"{parsed.path} {label}".casefold()
        ))
        path_parts = [part.casefold() for part in parsed.path.split("/") if part]
        if industry_review:
            # A news article under /about/ is not the company overview. Rank
            # the link itself, so that a large archive cannot hide service
            # locators inside the same existing navigation allowance.
            words = set(re.findall(
                r"[a-z]+", f"{path_parts[-1] if path_parts else ''} {label}".casefold()
            ))
        service_locator = industry_review and bool(
            set(path_parts) & {"service", "services", "product", "products", "platform", "platforms"}
        ) and not bool(set(path_parts) & {"news", "newsroom", "blog", "blogs", "articles"})
        priority = (
            0 if words & {
                "pricing", "price", "prices", "plan", "plans",
                "subscription", "subscriptions",
            } and not _commercial_terms_navigation_locator(canonical, label)
            else 1 if words & {"contact", "about", "headquarters"}
            or (industry_review and path_parts and path_parts[-1] in {"news", "newsroom", "investors"})
            else 2 if _commercial_terms_navigation_locator(canonical, label)
            else 3 if service_locator or words & {"product", "products", "platform", "platforms"}
            else 4
        )
        candidates.append((priority, {"url": canonical, "label": label}))

    locators: list[dict[str, str]] = []
    total_characters = 0
    for _priority, candidate in sorted(candidates, key=lambda item: item[0]):
        candidate_characters = len(candidate["url"]) + len(candidate["label"])
        if total_characters + candidate_characters > MAX_HOMEPAGE_NAVIGATION_TOTAL_CHARACTERS:
            continue
        locators.append(candidate)
        total_characters += candidate_characters
        if len(locators) >= MAX_HOMEPAGE_NAVIGATION_LOCATORS:
            break
    return locators


def _homepage_organization_url(
    raw_url: object, observed_domain: str, homepage_url: str = "",
) -> str:
    """Resolve relative metadata only against the fetched homepage origin."""

    if not isinstance(raw_url, str) or not 0 < len(raw_url) <= 2048:
        return ""
    try:
        parts = urlsplit(raw_url)
        if not parts.scheme and not parts.netloc:
            base = public_http_url(homepage_url)
            base_parts = urlsplit(base)
            if base_parts.scheme != "https":
                return ""
            organization_url = public_http_url(urljoin(base, raw_url))
            resolved = urlsplit(organization_url)
            if (resolved.scheme, resolved.netloc) != (
                base_parts.scheme, base_parts.netloc
            ):
                return ""
        else:
            organization_url = public_http_url(raw_url)
        if _registrable_domain(organization_url) == observed_domain:
            return organization_url
    except (NormalizationError, TypeError, ValueError):
        pass
    return ""


def _bound_homepage_organization_records(
    parser: _HomepageIdentityParser,
    observed_domain: str,
    observed_linkedin: str,
    homepage_url: str = "",
) -> list[dict[str, object]]:
    """Bind one unambiguous legal/brand pair to the homepage and LinkedIn."""

    if (
        not observed_domain or not observed_linkedin
        or parser.organization_identity_overflow
        or len(parser.organization_records) > 10
    ):
        return []
    records: list[dict[str, object]] = []
    brands, legal_names = set(), set()
    for record in parser.organization_records:
        name = record.get("name")
        if (
            not isinstance(name, str)
            or not 2 < len(name.strip()) <= _MAX_ORGANIZATION_NAME_LENGTH
            or not _company_name(name)
            or record.get("linkedin_urls") != [observed_linkedin]
        ):
            continue
        organization_url = _homepage_organization_url(
            record.get("url"), observed_domain, homepage_url,
        )
        if not organization_url:
            continue
        brands.add(_company_name(name))
        legal = record.get("legal_name")
        if (
            isinstance(legal, str)
            and 2 < len(legal.strip()) <= _MAX_ORGANIZATION_NAME_LENGTH
            and _company_name(legal)
        ):
            legal_names.add(_company_name(legal))
            records.append({**record, "url": organization_url})
    return records if len(brands) == len(legal_names) == 1 else []


def _homepage_company_names(
    page_text: str,
    *,
    observed_domain: str = "",
    observed_linkedin: str = "",
    homepage_url: str = "",
) -> list[str]:
    """Return names actually observed in title or first-party metadata."""

    parser = _HomepageIdentityParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
    except Exception:
        return []
    candidates = [
        *parser.metadata_names, *parser.copyright_legal_names,
        *_inline_footer_copyright_names(page_text, parser.copyright_legal_names),
    ]
    # Preserve brand discovery while requiring a unique explicit legal relation.
    organization_names: dict[str, str] = {}
    if observed_domain and observed_linkedin:
        for record in parser.organization_records:
            name = record.get("name")
            if (
                isinstance(name, str)
                and 2 < len(name.strip()) <= _MAX_ORGANIZATION_NAME_LENGTH
                and _company_name(name)
                and record.get("linkedin_urls") == [observed_linkedin]
                and _homepage_organization_url(
                    record.get("url"), observed_domain, homepage_url,
                )
            ):
                organization_names.setdefault(_company_name(name), name.strip())
    records = _bound_homepage_organization_records(
        parser, observed_domain, observed_linkedin, homepage_url,
    )
    candidates = [
        *(organization_names.values() if len(organization_names) == 1 else ()),
        *(str(record["legal_name"]).strip() for record in records), *candidates,
    ]
    if parser.title:
        candidates.append(parser.title)
        candidates.extend(
            part.strip()
            # Product homepages commonly use ``Brand: tagline`` without a
            # space before the colon. Keep the conservative whitespace rule
            # for dash-like separators so hyphenated brand names are intact.
            for part in re.split(
                r"\s+(?:\||-|\N{EN DASH}|\N{EM DASH})\s+|\s*:\s*",
                parser.title,
            )
            if part.strip()
        )
    generic = {"home", "homepage", "welcome", "official site", "website"}
    return list(dict.fromkeys(
        candidate
        for candidate in candidates
        if candidate.casefold() not in generic and 2 < len(candidate) <= 200
    ))[:10]


def _bound_homepage_organization_identity(
    page_text: str, observed_domain: str, observed_linkedins: list[str],
    homepage_url: str = "",
) -> dict[str, str]:
    """Keep one first-party Organization identity for later conflict checks."""

    if len(observed_linkedins) != 1:
        return {}
    parser = _HomepageIdentityParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return {}
    metadata_names = {_company_name(name) for name in parser.metadata_names}
    if len(metadata_names) != 1:
        return {}
    bound_names = set()
    for record in parser.organization_records:
        name = record.get("name")
        if not isinstance(name, str) or not _homepage_organization_url(
            record.get("url"), observed_domain, homepage_url,
        ):
            continue
        linkedins = record.get("linkedin_urls")
        if linkedins and linkedins != observed_linkedins:
            return {}
        bound_names.add(_company_name(name))
    if len(bound_names) != 1 or bound_names != metadata_names:
        return {}
    slug = urlsplit(observed_linkedins[0]).path.rstrip("/").rsplit("/", 1)[-1]
    return {
        "normalized_name": next(iter(bound_names)),
        "registrable_dns_domain": observed_domain,
        "linkedin_company_slug": slug,
    }


def _verified_organization_legal_name_aliases(
    page_text: str,
    *,
    observed_domain: str,
    observed_name: str,
    observed_linkedin: str,
    company_quality: bool = False,
    homepage_url: str = "",
) -> list[str]:
    """Return legal names explicitly bound to the verified homepage entity."""

    parser = _HomepageIdentityParser()
    try:
        parser.feed(str(page_text or "")[:_MAX_BYTES])
        parser.close()
    except Exception:
        return []
    aliases: list[str] = []
    for record in _bound_homepage_organization_records(
        parser, observed_domain, observed_linkedin, homepage_url,
    ):
        brand, legal_name = record.get("name"), record.get("legal_name")
        if (
            not isinstance(legal_name, str)
            or not 2 < len(legal_name.strip()) <= _MAX_ORGANIZATION_NAME_LENGTH
            or _company_name(observed_name) not in {
                _company_name(brand), _company_name(legal_name),
            }
        ):
            continue
        if legal_name.strip() not in aliases:
            aliases.append(legal_name.strip())
        if len(aliases) == _MAX_ORGANIZATION_LEGAL_NAME_ALIASES:
            break
    return aliases


def _identity_result(
    receipt: Mapping[str, object],
    reason: str,
    *,
    actual_final_url: str = "",
    source_fetch_failed: bool = False,
    failure_reason_code: str = "",
    verified_homepage_transport_domain: str = "",
    verified_rebrand_redirect: Optional[Mapping[str, str]] = None,
    observed_homepage_organization_identity: Optional[Mapping[str, str]] = None,
) -> CompanyFitDecisionResult:
    details = {
        "identity": dict(receipt),
        "actual_final_url": str(actual_final_url or ""),
        **(
            {
                "verified_homepage_transport_domain": (
                    verified_homepage_transport_domain
                )
            }
            if verified_homepage_transport_domain
            else {}
        ),
        **(
            {"failure_reason_code": failure_reason_code or "source_blocked"}
            if source_fetch_failed or failure_reason_code
            else {}
        ),
        **(
            {VERIFIED_REBRAND_REDIRECT_KEY: dict(verified_rebrand_redirect)}
            if verified_rebrand_redirect
            else {}
        ),
        **(
            {"observed_homepage_organization_identity": dict(observed_homepage_organization_identity)}
            if observed_homepage_organization_identity
            else {}
        ),
    }
    if receipt["decision"] == "match":
        return company_fit_match(reason, details=details)
    if receipt["decision"] == "mismatch":
        return company_fit_mismatch(reason, details=details)
    return company_fit_unavailable(reason, details=details)


class _ArenaProviderFetchError(aiohttp.ClientError):
    """An Arena error response has no validated target response URL."""

    def __init__(
        self, message: str, *, broker_status: Optional[int] = None,
        broker_error_code: str = "",
    ):
        super().__init__(message)
        self.broker_status = (
            broker_status
            if type(broker_status) is int and 100 <= broker_status <= 599
            else None
        )
        self.broker_error_code = (
            "provider_request_refused"
            if self.broker_status == 403
            and broker_error_code == "provider_request_refused"
            else ""
        )


_ARENA_PROVIDER_REQUEST_REFUSED_BODY = (
    b'{"error":{"code":"provider_request_refused"}}'
)


async def _fetch_bounded_html(
    session: aiohttp.ClientSession,
    url: str,
    *,
    params: Optional[Mapping[str, str]] = None,
) -> tuple[int, str, str]:
    request_kwargs = {"params": dict(params)} if params is not None else {}
    async with session.get(
        url, allow_redirects=True, **request_kwargs,
    ) as resp:
        if (
            resp.status >= 400
            and getattr(resp, "_lab_arena_response_url_validated", None) is False
        ):
            broker_error_code = ""
            if (
                resp.status == 403
                and bool(getattr(resp, "headers", {}).get(
                    "x-leadpoet-call-identity"
                ))
            ):
                # The broker's fixed refusal has no target URL. Read at most
                # one byte beyond its exact envelope; never return this body
                # or the shim's request-URL fallback as page evidence.
                raw_error = bytearray()
                while len(raw_error) <= len(_ARENA_PROVIDER_REQUEST_REFUSED_BODY):
                    chunk = await resp.content.read(
                        len(_ARENA_PROVIDER_REQUEST_REFUSED_BODY) + 1
                        - len(raw_error)
                    )
                    if not chunk:
                        break
                    raw_error.extend(chunk)
                if bytes(raw_error) == _ARENA_PROVIDER_REQUEST_REFUSED_BODY:
                    broker_error_code = "provider_request_refused"
            raise _ArenaProviderFetchError(
                "website fetch error: Arena provider response unavailable",
                broker_status=resp.status,
                broker_error_code=broker_error_code,
            )
        raw = bytearray()
        while len(raw) < _MAX_BYTES:
            chunk = await resp.content.read(_MAX_BYTES - len(raw))
            if not chunk:
                break
            raw.extend(chunk)
        return (
            resp.status,
            str(getattr(resp, "url", url) or url),
            _decode_homepage_html(
                raw,
                _content_type_header(getattr(resp, "headers", {})),
            ),
        )


# ----------------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------------

async def verify_company_exists(
    company_name: str,
    company_website: str,
    timeout_secs: float = _HTTP_TIMEOUT_SECS,
    *,
    company_linkedin: str = "",
    require_https_transport: bool = False,
    company_quality: bool = False,
    homepage_navigation_locator_sink: Optional[list[dict[str, str]]] = None,
    homepage_evidence_sink: Optional[dict[str, dict[str, Any]]] = None,
) -> CompanyFitDecisionResult:
    """Verify that ``company_website`` is a real page for ``company_name``.

    Returns a ``company-fit-decision:v1`` result with named decision state.

      * ``"verified: name 'ExampleCo' found in homepage"`` (best case)
      * ``"homepage identity evidence unavailable: ..."``
      * ``"website is a parked / for-sale page"``
      * ``"website unreachable: ..."``
    """
    if homepage_navigation_locator_sink is not None:
        homepage_navigation_locator_sink.clear()
    if homepage_evidence_sink is not None:
        homepage_evidence_sink.clear()
    submitted_identity = evaluate_company_identity(
        submitted_name=company_name,
        submitted_website=company_website,
        submitted_linkedin=company_linkedin,
        observed_name="",
        observed_website="",
        observed_linkedin="",
        evidence_source="company_homepage",
        company_quality=company_quality,
    )
    if submitted_identity["decision"] == "mismatch":
        return _identity_result(
            submitted_identity,
            "submitted company identity is missing or invalid",
        )

    request_url = (
        _upgrade_plain_http_company_url(company_website)
        if require_https_transport
        else company_website.strip()
    )

    try:
        domain = _registrable_domain(request_url)
    except NormalizationError:
        submitted_identity.update(
            decision="mismatch", reason_code="identity_unresolved"
        )
        return _identity_result(
            submitted_identity,
            f"company_website has no valid registrable domain: {company_website!r}",
        )
    except Exception as exc:  # Pinned identity primitive is unavailable.
        return _identity_result(
            submitted_identity,
            f"company identity normalization unavailable: {type(exc).__name__}",
        )

    timeout = aiohttp.ClientTimeout(total=timeout_secs, connect=min(3.0, timeout_secs))

    try:
        for attempt in range(_TRANSIENT_FETCH_ATTEMPTS):
            try:
                async with aiohttp.ClientSession(
                    timeout=timeout,
                    headers=_HEADERS,
                ) as session:
                    status, observed_url, text = await _fetch_bounded_html(
                        session,
                        request_url,
                    )
                # Optional private source fingerprint; no decision or fetch changes.
                from qualification.scoring.company_fit_evidence_reuse import record_source
                record_source("homepage", {"url": request_url}, {
                    "status": status, "final_url": observed_url, "text": text,
                }, ok=status < 400)
                break
            except (aiohttp.ClientConnectionError, asyncio.TimeoutError):
                if attempt + 1 >= _TRANSIENT_FETCH_ATTEMPTS:
                    raise
                await asyncio.sleep(_TRANSIENT_FETCH_RETRY_DELAY_SECS)
    except (aiohttp.ClientConnectionError, asyncio.TimeoutError) as e:
        return _identity_result(
            submitted_identity,
            f"website unreachable: {type(e).__name__}: {str(e)[:120]}",
            source_fetch_failed=(
                getattr(e, "_lab_arena_response_url_validated", None) is not False
            ),
            failure_reason_code=(
                "provider_error"
                if getattr(e, "_lab_arena_response_url_validated", None) is False
                else ""
            ),
        )
    except _ArenaProviderFetchError as e:
        return _identity_result(
            submitted_identity,
            str(e),
            failure_reason_code=(
                "source_blocked"
                if e.broker_status == 403
                and e.broker_error_code == "provider_request_refused"
                else "provider_error"
            ),
        )
    except aiohttp.ClientError as e:
        return _identity_result(
            submitted_identity,
            f"website unreachable: {type(e).__name__}: {str(e)[:120]}",
        )
    except Exception as e:  # noqa: BLE001 - log everything else and fall through
        return _identity_result(
            submitted_identity,
            f"website fetch error: {type(e).__name__}: {str(e)[:120]}",
        )

    # ----- Status checks ----------------------------------------------------
    # 200 = ideal.  3xx are already followed by aiohttp.  4xx/5xx mean
    # the page itself is not a usable company page.
    if status >= 400:
        return _identity_result(
            submitted_identity, f"website returned HTTP {status}",
            actual_final_url=observed_url,
            # These are failures of this bounded page fetch. Account and
            # quota refusals remain distinct from unavailable source evidence.
            source_fetch_failed=status in {408, 425, 500, 502, 503, 504},
        )

    if require_https_transport and not _is_https_url(observed_url):
        return _identity_result(
            submitted_identity,
            "homepage identity evidence unavailable: final URL is not HTTPS",
            actual_final_url=observed_url,
        )

    try:
        observed_domain = _registrable_domain(observed_url)
    except Exception as exc:
        return _identity_result(
            submitted_identity,
            "homepage identity evidence unavailable: observed domain "
            f"normalization failed ({type(exc).__name__})",
            actual_final_url=observed_url,
        )
    if observed_domain != domain:
        redirect_receipt = dict(submitted_identity)
        redirect_receipt.update(
            decision="mismatch",
            reason_code="identity_mismatch",
            observed_domain=observed_domain,
        )
        verified_rebrand_redirect: dict[str, str] = {}
        if (
            not _PARKED_DOMAIN_RE.search(text)
            and not _homepage_body_is_unusable(text)
        ):
            submitted_linkedin = _canonical_linkedin_company_url(
                company_linkedin
            )
            observed_linkedins = _homepage_company_linkedin_urls(text)
            try:
                canonical_request_url = public_http_url(request_url)
                canonical_final_url = public_http_url(observed_url)
                request_parts = urlsplit(canonical_request_url)
                final_parts = urlsplit(canonical_final_url)
            except (NormalizationError, TypeError, ValueError):
                canonical_request_url = ""
                canonical_final_url = ""
                request_parts = None
                final_parts = None
            if (
                submitted_linkedin
                and observed_linkedins == [submitted_linkedin]
                and request_parts is not None
                and final_parts is not None
                and request_parts.scheme.casefold() == "https"
                and final_parts.scheme.casefold() == "https"
                and request_parts.username is None
                and request_parts.password is None
                and final_parts.username is None
                and final_parts.password is None
                and request_parts.fragment == ""
                and final_parts.fragment == ""
                and request_parts.port in {None, 443}
                and final_parts.port in {None, 443}
            ):
                verified_rebrand_redirect = {
                    "source": "server_homepage_redirect_v1",
                    "submitted_name": company_name.strip(),
                    "submitted_domain": domain,
                    "observed_domain": observed_domain,
                    "submitted_linkedin_slug": submitted_linkedin.rsplit("/", 1)[-1],
                    "observed_linkedin_slug": submitted_linkedin.rsplit("/", 1)[-1],
                    "request_url": canonical_request_url,
                    "final_url": canonical_final_url,
                }
                if homepage_evidence_sink is not None:
                    from qualification.scoring.company_evidence_investigator import (
                        _plain_text, _homepage_industry_link_metadata,
                    )

                    evidence_text = _plain_text(text)
                    if evidence_text:
                        homepage_evidence_sink[canonical_request_url] = {
                            "final_url": canonical_final_url,
                            "text": evidence_text,
                            **_homepage_industry_link_metadata(
                                text, canonical_request_url, canonical_final_url, evidence_text,
                                company_name),
                        }
        return _identity_result(
            redirect_receipt,
            f"company identity conflict: redirect changed registrable domain "
            f"from {domain!r} to {observed_domain!r}",
            actual_final_url=observed_url,
            verified_rebrand_redirect=verified_rebrand_redirect,
        )

    # ----- Parked-domain detection ------------------------------------------
    if _PARKED_DOMAIN_RE.search(text):
        submitted_identity.update(decision="mismatch", reason_code="identity_mismatch")
        return _identity_result(
            submitted_identity,
            "website is a parked / for-sale page",
            actual_final_url=observed_url,
        )

    if _homepage_body_is_unusable(text):
        return _identity_result(
            submitted_identity,
            "website fetch error: homepage response body is unusable",
            actual_final_url=observed_url,
            verified_homepage_transport_domain=domain,
            failure_reason_code="malformed_response",
        )
    observed_linkedins = _homepage_company_linkedin_urls(text)
    observed_names = _homepage_company_names(
        text,
        observed_domain=observed_domain,
        homepage_url=observed_url,
        observed_linkedin=(
            observed_linkedins[0] if len(observed_linkedins) == 1 else ""
        ),
    )
    if observed_names and not observed_linkedins:
        source_url = _linked_identity_source_url(
            text,
            base_url=observed_url,
            registrable_domain=domain,
        )
        if source_url:
            try:
                async with aiohttp.ClientSession(
                    timeout=timeout,
                    headers=_HEADERS,
                ) as session:
                    source_status, source_final_url, source_text = (
                        await _fetch_bounded_html(session, source_url)
                    )
                from qualification.scoring.company_fit_evidence_reuse import record_source
                record_source("homepage", {"url": source_url}, {
                    "status": source_status, "final_url": source_final_url, "text": source_text,
                }, ok=source_status < 400)
            except (aiohttp.ClientError, asyncio.TimeoutError):
                pass
            else:
                try:
                    source_domain = _registrable_domain(source_final_url)
                except Exception:
                    source_domain = ""
                source_linkedins = _homepage_company_linkedin_urls(source_text)
                if (
                    source_status < 400
                    and _is_https_url(source_final_url)
                    and source_domain == domain
                    and len(source_linkedins) == 1
                    and any(
                        evaluate_company_identity(
                            submitted_name=homepage_name,
                            submitted_website=f"https://{domain}",
                            submitted_linkedin=source_linkedins[0],
                            observed_name=source_name,
                            observed_website=f"https://{domain}",
                            observed_linkedin=source_linkedins[0],
                            evidence_source="company_homepage",
                            company_quality=False,
                        )["decision"] == "match"
                        for homepage_name in observed_names
                        for source_name in _homepage_company_names(source_text)
                    )
                ):
                    observed_linkedins = source_linkedins
    if not observed_names:
        return _identity_result(
            submitted_identity,
            "homepage identity evidence unavailable: company name metadata not found",
            actual_final_url=observed_url,
            verified_homepage_transport_domain=domain,
        )
    if not observed_linkedins:
        # The missing LinkedIn binding makes identity unavailable, but the
        # already fetched same-domain homepage can still be useful as
        # untrusted evidence after independent web identity verification.
        if (
            homepage_evidence_sink is not None
            and any(_company_name(name) == _company_name(company_name)
                    for name in observed_names)
        ):
            from qualification.scoring.company_evidence_investigator import (
                _plain_text, _homepage_industry_link_metadata,
            )

            try:
                canonical_request_url = public_http_url(request_url)
                canonical_final_url = public_http_url(observed_url)
                request_parts = urlsplit(canonical_request_url)
                final_parts = urlsplit(canonical_final_url)
            except (TypeError, ValueError):
                canonical_request_url = ""
                canonical_final_url = ""
                request_parts = None
                final_parts = None
            if (
                request_parts is not None
                and final_parts is not None
                and request_parts.scheme == final_parts.scheme == "https"
                and request_parts.username is None
                and request_parts.password is None
                and final_parts.username is None
                and final_parts.password is None
                and request_parts.fragment == final_parts.fragment == ""
                and request_parts.port in {None, 443}
                and final_parts.port in {None, 443}
                and _registrable_domain(canonical_request_url) == domain
                and _registrable_domain(canonical_final_url) == domain
                and (evidence_text := _plain_text(text))
            ):
                homepage_evidence_sink[canonical_request_url] = {
                    "final_url": canonical_final_url,
                    "text": evidence_text,
                    **_homepage_industry_link_metadata(
                        text, canonical_request_url, canonical_final_url, evidence_text,
                        company_name),
                }
                if homepage_navigation_locator_sink is not None:
                    homepage_navigation_locator_sink.extend(
                        _homepage_navigation_locators(
                            text, final_url=observed_url, verified_domain=domain,
                        )
                    )
        return _identity_result(
            submitted_identity,
            "homepage identity evidence unavailable: LinkedIn company binding not found",
            actual_final_url=observed_url,
            verified_homepage_transport_domain=domain,
        )
    bound_organization = _bound_homepage_organization_identity(
        text, observed_domain, observed_linkedins, observed_url
    )
    identity_receipts = [
        evaluate_company_identity(
            submitted_name=company_name,
            submitted_website=company_website,
            submitted_linkedin=company_linkedin,
            observed_name=observed_name,
            observed_website=observed_url,
            observed_linkedin=observed_linkedin,
            evidence_source="company_homepage",
            company_quality=company_quality,
        )
        for observed_name in observed_names
        for observed_linkedin in observed_linkedins
    ]
    matched_receipts = [
        receipt for receipt in identity_receipts if receipt["decision"] == "match"
    ]
    submitted_name_key = _company_name(company_name)
    matched = next(
        (
            receipt for receipt in matched_receipts
            if receipt["observed_name"] == submitted_name_key
        ),
        matched_receipts[0] if matched_receipts else None,
    )
    if matched is not None:
        matched_receipt: dict[str, object] = dict(matched)
        matched_linkedin = (
            "https://www.linkedin.com/company/"
            f"{matched['observed_linkedin_slug']}"
        )
        legal_name_aliases = _verified_organization_legal_name_aliases(
            text,
            observed_domain=matched["observed_domain"],
            observed_name=matched["observed_name"],
            observed_linkedin=matched_linkedin,
            company_quality=company_quality,
            homepage_url=observed_url,
        )
        if legal_name_aliases:
            matched_receipt["verified_legal_name_aliases"] = legal_name_aliases
            parser = _HomepageIdentityParser()
            parser.feed(text[:_MAX_BYTES])
            parser.close()
            bound_records = _bound_homepage_organization_records(
                parser, matched["observed_domain"], matched_linkedin, observed_url,
            )
            if bound_records:
                matched_receipt["verified_brand_name"] = str(
                    bound_records[0]["name"]
                ).strip()
        if homepage_navigation_locator_sink is not None:
            homepage_navigation_locator_sink.extend(
                _homepage_navigation_locators(
                    text,
                    final_url=observed_url,
                    verified_domain=str(matched["observed_domain"]),
                )
            )
        if homepage_evidence_sink is not None:
            # The investigator owns the exact visible-text and binary guards.
            # Import here to avoid a module cycle during initialization.
            from qualification.scoring.company_evidence_investigator import (
                _plain_text, _homepage_industry_link_metadata,
            )

            try:
                request_domain = _registrable_domain(request_url)
                final_domain = _registrable_domain(observed_url)
                canonical_request_url = public_http_url(request_url)
                canonical_final_url = public_http_url(observed_url)
                request_parts = urlsplit(canonical_request_url)
                final_parts = urlsplit(canonical_final_url)
            except (NormalizationError, TypeError, ValueError):
                request_domain = ""
                final_domain = ""
                canonical_request_url = ""
                canonical_final_url = ""
                request_parts = None
                final_parts = None
            evidence_text = _plain_text(text)
            if (
                evidence_text
                and request_parts is not None
                and final_parts is not None
                and request_parts.scheme.casefold() == "https"
                and final_parts.scheme.casefold() == "https"
                and request_parts.username is None
                and request_parts.password is None
                and final_parts.username is None
                and final_parts.password is None
                and request_parts.fragment == ""
                and final_parts.fragment == ""
                and request_parts.port in {None, 443}
                and final_parts.port in {None, 443}
                and request_domain == matched["observed_domain"]
                and final_domain == matched["observed_domain"]
            ):
                homepage_evidence_sink[canonical_request_url] = {
                    "final_url": canonical_final_url,
                    "text": evidence_text,
                    **_homepage_industry_link_metadata(
                        text, canonical_request_url, canonical_final_url, evidence_text,
                        company_name),
                }
        return _identity_result(
            matched_receipt,
            "verified: independently observed first-party name, final domain, "
            "and exact LinkedIn company identity",
            actual_final_url=observed_url,
        )
    if len(observed_linkedins) == 1 and homepage_evidence_sink is not None:
        # An incomplete homepage identity can still supply untrusted source
        # text. Carry its observed LinkedIn slug so the later independent web
        # identity gate can reject a different company on the same domain.
        from qualification.scoring.company_evidence_investigator import (
            _plain_text, _homepage_industry_link_metadata,
        )

        evidence_text = _plain_text(text)
        visible_text = evidence_text.partition(
            "[[SERVER_VISIBLE_LINK_DESTINATIONS_FOR_IDENTITY_ONLY]]"
        )[0]
        name_pattern = re.escape(" ".join(company_name.split())).replace(
            r"\ ", r"\s+"
        )
        name_visible = bool(
            name_pattern
            and re.search(rf"(?<!\w){name_pattern}(?!\w)", visible_text, re.I)
        )
        try:
            canonical_request_url = public_http_url(request_url)
            canonical_final_url = public_http_url(observed_url)
            request_parts = urlsplit(canonical_request_url)
            final_parts = urlsplit(canonical_final_url)
        except (TypeError, ValueError):
            canonical_request_url = canonical_final_url = ""
            request_parts = final_parts = None
        if (
            request_parts is not None
            and final_parts is not None
            and request_parts.scheme == final_parts.scheme == "https"
            and request_parts.username is None
            and request_parts.password is None
            and final_parts.username is None
            and final_parts.password is None
            and request_parts.fragment == final_parts.fragment == ""
            and request_parts.port in {None, 443}
            and final_parts.port in {None, 443}
            and evidence_text
            and (
                name_visible
                or any(
                    _company_name(name) == _company_name(company_name)
                    for name in observed_names
                )
            )
        ):
            homepage_evidence_sink[canonical_request_url] = {
                "final_url": canonical_final_url,
                "text": evidence_text,
                **_homepage_industry_link_metadata(
                    text, canonical_request_url, canonical_final_url, evidence_text,
                    company_name),
                "observed_linkedin_slug": urlsplit(
                    observed_linkedins[0]
                ).path.rstrip("/").rsplit("/", 1)[-1].casefold(),
            }
            if homepage_navigation_locator_sink is not None:
                homepage_navigation_locator_sink.extend(
                    _homepage_navigation_locators(
                        text, final_url=observed_url, verified_domain=domain,
                    )
                )
    conflict = next(
        (receipt for receipt in identity_receipts if receipt["decision"] == "mismatch"),
        None,
    )
    if conflict is not None:
        # Page titles can be marketing copy, and outgoing company links can
        # name a parent, partner, or an old LinkedIn slug. Their disagreement
        # is not a proven entity conflict on the same final domain. Defer to
        # the existing independent web verifier; do not mark this as a match
        # or supply it as a verified identity anchor. Invalid domains, parked
        # pages, and cross-domain redirects remain terminal checks above.
        unresolved = dict(conflict)
        unresolved.update(decision="unavailable", reason_code="identity_not_proven")
        return _identity_result(
            unresolved,
            "homepage identity evidence unavailable: page metadata and links "
            "do not prove the submitted identity",
            actual_final_url=observed_url,
            verified_homepage_transport_domain=domain,
            observed_homepage_organization_identity=bound_organization,
        )
    unavailable_receipts = [
        receipt for receipt in identity_receipts if receipt["decision"] == "unavailable"
    ]
    # Retain an exact observed name as lookup context before SEO copy. This
    # grants no identity; preserve the independent Organization conflict below.
    unavailable = next(
        (receipt for receipt in unavailable_receipts
         if len(observed_linkedins) == 1
         and receipt["observed_name"] == submitted_name_key),
        unavailable_receipts[0] if unavailable_receipts else None,
    )
    if unavailable is not None:
        return _identity_result(
            unavailable,
            "homepage identity evidence unavailable: complete identity not proven",
            actual_final_url=observed_url,
            verified_homepage_transport_domain=domain,
            observed_homepage_organization_identity=bound_organization,
        )
    return _identity_result(
        submitted_identity,
        "homepage identity evidence unavailable: complete identity not proven",
        actual_final_url=observed_url,
        verified_homepage_transport_domain=domain,
        observed_homepage_organization_identity=bound_organization,
    )
